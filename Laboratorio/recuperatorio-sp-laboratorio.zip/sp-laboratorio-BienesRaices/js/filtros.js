function filtrarAnuncios(array) {
    let nuevoObjeto = array;
    let filtro = $('#selTransaccion option:selected').val();
    if (filtro != 'Todos') {
        nuevoObjeto = nuevoObjeto.filter(elemento => elemento.transaccion == filtro).unique();
    }
    let promedioPrecio = nuevoObjeto.map(elemento => elemento.precio).reduce((suma, precio, indice, array) => (suma + precio) / array.length, 0);
    let procentajeVentas = (nuevoObjeto.filter(elemento => elemento.transaccion === 'Venta').length / nuevoObjeto.length) * 100;
    if (isNaN(procentajeVentas)) {
        procentajeVentas = 0;
    }
    $('#promedioPrecio').val(promedioPrecio);
    $('#procentajeVentas').val(procentajeVentas);
    return nuevoObjeto;
}

function mascaras() {
    let checkColumna = $('#filtroColumnas :checkbox').map(function () { return $(this).val(); }).get();
    for (i of checkColumna) {
        if ($('#filtroColumnas :checkbox[value="' + i + '"]').prop('checked')) {
            $('#tabla [value="' + i + '"]').prop('hidden', false);
        }
        else {
            $('#tabla [value="' + i + '"]').prop('hidden', true);
        }
    }
}

Array.prototype.unique = function () {
    return [...new Set(this)];
}
















//no!...funciona, pero mucho quilombo
/*function actualizarFiltros() {


    nuevoObjeto = nuevoObjeto.map(elemento => {
        for (i of checkColumna) {
            delete (elemento[i]);
        }
        return elemento;
    }).unique();
    let chboxValores = $('#mascarasTabla :input[type=checkbox]');
    chboxValores = chboxValores.length;
    for (i = 0; i < chboxValores; i++) {
        $('input[type=checkbox][value=' + i + ']').change(checkboxMarcado);
    }
    $('#btnFiltrar').click(filtrarAnuncios);
}

function checkboxMarcado() {
    if ($(this).prop('checked')) {
        mostrarColumna($(this).val(), true);
    } else {
        mostrarColumna($(this).val(), false);
    }
}

function mostrarColumna(idNodoColumna, mostrar) {
    let filas = $('tr');
    if (mostrar) {
        for (i = 0; i < filas.length; i++) {
            let nodo = filas[i].childNodes;
            $(nodo[idNodoColumna]).prop('hidden', false);
        }
    }
    else {
        for (i = 0; i < filas.length; i++) {
            let nodo = filas[i].childNodes;
            $(nodo[idNodoColumna]).prop('hidden', true);
        }
    }
}

function filtrarAnuncios()
{
    let filas = $('tr');
    if(!$('#filtroVenta').prop('checked'))
    {

    }
}*/