let Anuncio = function(id,titulo,descripcion,transaccion,precio,num_wc,num_dormitorios,num_estacionamientos){
    this.id =id;
    this.titulo =titulo;
    this.descripcion = descripcion;
    this.transaccion =transaccion;
    this.precio =precio;
    this.num_wc =num_wc;
    this.num_dormitorios =num_dormitorios;
    this.num_estacionamientos =num_estacionamientos;
}

