class Persona {
  private _nombre: string;
  private _apellido: string;
  private _edad: number;
  private _email: string;
  private _sexo: string;
  private _cargo: string;

  constructor(
    nombre: string,
    apellido: string,
    edad: number,
    email: string,
    sexo: string,
    cargo: string
  ) {
    this._nombre = nombre;
    this._apellido = apellido;
    this._edad = edad;
    this._email = email;
    this._sexo = sexo;
    this._cargo = cargo;
  }

  get nombre(): string {
    return this._nombre;
  }
  set nombre(e: string) {
    this._nombre = e;
  }
  get apellido(): string {
    return this._apellido;
  }
  set apellido(e: string) {
    this._apellido = e;
  }
  get edad(): number {
    return this._edad;
  }
  set edad(e: number) {
    this._edad = e;
  }
  get email(): string {
    return this._email;
  }
  set email(e: string) {
    this._email = e;
  }
  get sexo(): string {
    return this._sexo;
  }
  set sexo(e: string) {
    this._sexo = e;
  }
  get cargo(): string {
    return this._cargo;
  }
  set cargo(e: string) {
    this._cargo = e;
  }
}
