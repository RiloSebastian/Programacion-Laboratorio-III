var Persona = /** @class */ (function () {
    function Persona(nombre, apellido, edad, email, sexo, cargo) {
        this._nombre = nombre;
        this._apellido = apellido;
        this._edad = edad;
        this._email = email;
        this._sexo = sexo;
        this._cargo = cargo;
    }
    Object.defineProperty(Persona.prototype, "nombre", {
        get: function () {
            return this._nombre;
        },
        set: function (e) {
            this._nombre = e;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Persona.prototype, "apellido", {
        get: function () {
            return this._apellido;
        },
        set: function (e) {
            this._apellido = e;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Persona.prototype, "edad", {
        get: function () {
            return this._edad;
        },
        set: function (e) {
            this._edad = e;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Persona.prototype, "email", {
        get: function () {
            return this._email;
        },
        set: function (e) {
            this._email = e;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Persona.prototype, "sexo", {
        get: function () {
            return this._sexo;
        },
        set: function (e) {
            this._sexo = e;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Persona.prototype, "cargo", {
        get: function () {
            return this._cargo;
        },
        set: function (e) {
            this._cargo = e;
        },
        enumerable: true,
        configurable: true
    });
    return Persona;
}());
