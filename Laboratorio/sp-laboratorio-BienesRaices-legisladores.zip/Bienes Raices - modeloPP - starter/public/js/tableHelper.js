
//trabaja con el array de objetos
function crearTabla(array) {
    var tabla = document.createElement("table");
    tabla.className = 'tabla';
    let cabecera = document.createElement("tr");
    for (atributo in array[0]) {
        if (atributo != "toString") {
            if (atributo != 'active') {
                let th = document.createElement("th");
                th.textContent = atributo;
                cabecera.appendChild(th);
            }
        }
    }
    tabla.appendChild(cabecera);
    for (i in array) {
        var fila = document.createElement("tr");
        var objeto = array[i];
        for (j in objeto) {
            if (j != "toString") {

                if (j != 'active') {
                    var celda = document.createElement("td");
                    var dato = document.createTextNode(objeto[j]);
                    celda.appendChild(dato);
                    $(celda).click(traerValores);
                    fila.appendChild(celda);
                }
            }
        }
        tabla.appendChild(fila);
    }   
    return tabla;
}

//trabaja directamente con el objeto
/*function crearTabla(anuncio) {

    let tabla = document.createElement('table');
    tabla.className = 'tabla';
    let cabecera = document.createElement('tr');
    for (parametro in anuncio) {
        let th = document.createElement('th');
        th.textContent = parametro;
        cabecera.appendChild(th);
    }
    tabla.appendChild(cabecera);
    let fila = document.createElement('tr');
    for (i in anuncio) {
        let celda = document.createElement('td');
        celda.textContent = anuncio[i];
        fila.appendChild(celda);
        $(celda).click(traerValores);
    }
    
    tabla.appendChild(fila);
    return tabla;
}*/