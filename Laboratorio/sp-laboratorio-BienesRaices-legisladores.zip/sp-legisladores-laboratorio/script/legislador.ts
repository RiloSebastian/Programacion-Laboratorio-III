/// <reference path="persona.ts" />

class Legislador extends Persona{
    private tipo:tipoLegislador;

    constructor(id:number,nombre:string,apellido:string,edad:number,email:string,sexo:string,tipo:tipoLegislador){
        super(id,nombre,apellido,edad,email,sexo);
        this.tipo = tipo;
    }

    get Tipo():tipoLegislador{return this.tipo;};
    set Tipo(e:tipoLegislador){this.tipo = e;};
}