class Persona{
    private id:number;
    private nombre:string;
    private apellido:string;
    private edad:number;
    private email:string;
    private sexo:string;

    constructor(id:number,nombre:string,apellido:string,edad:number,email:string,sexo:string){
        this.id =id;
        this.nombre =nombre;
        this.apellido =apellido;
        this.edad =edad;
        this.email =email;
        this.sexo =sexo;
    }

    get Id():number{return this.id;};
    set Id(e:number){this.id = e;};

    get Nombre():string{return this.nombre;};
    set Nombre(e:string){this.nombre =e;};

    get Apellido():string{return this.apellido;};
    set Apellido(e:string){this.apellido =e;};

    get Edad():number{return this.edad;};
    set Edad(e:number){this.edad = e;};

    get Email():string{return this.email;};
    set Email(e:string){this.email =e;};

    get Sexo():string{return this.sexo;};
    set Sexo(e:string){this.sexo =e;};
}

enum tipoLegislador{
    Diputado,
    Senador
}