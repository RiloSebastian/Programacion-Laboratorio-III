function traerObjetos() {
   let array = obtenerArray();
   array = filtrarObjetos(array);
   if (array.length > 0) {
      let tabla = crearTabla(array);
   }
   else {
      $('#tabla').prop('innerHTML', '');
      $('#filtroColumnas').prop('innerHTML', '');
   }
}

function altaObjeto(objeto) {
   let array = obtenerArray();
   let id = generarID(array);
   objeto.id = id;
   array.push(objeto);
   localStorage.setItem('Objetos', JSON.stringify(array));
   traerObjetos();
}

function modificarObjeto(objeto) {
   let array = obtenerArray();
   for (i in array) {
      if (array[i].id === objeto.id) {
         array[i] = objeto;
      }
   }
   localStorage.setItem('Objetos', JSON.stringify(array));
   traerObjetos();
}

function bajaObjeto(id) {
   let array = obtenerArray();
   let nuevoArray = [];
   for (i in array) {
      if (array[i].id === id) {
         nuevoArray = array.filter(element => element.id != id);
      }
   }
   localStorage.setItem('Objetos', JSON.stringify(nuevoArray));
   traerObjetos();
}

function obtenerArray() {
   let array = localStorage.getItem('Objetos');
   if (array == null || array === '') {
      array = [];
   }
   else {
      array = JSON.parse(array);
   }
   return array;
}

function generarID(array) {
   let id = 0;
   if (array.length > 0) {
      for (i in array) {
         if (array[i].id >= id) {
            id = array[i].id;
         }
      }
   }
   return id + 1;
}