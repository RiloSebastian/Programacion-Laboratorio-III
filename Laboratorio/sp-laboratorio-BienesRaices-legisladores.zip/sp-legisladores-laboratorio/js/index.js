window.addEventListener('load', inicializarManejadores);
window.addEventListener('load', traerObjetos);

//modificar segun html
function inicializarManejadores() {
    $('#frm').submit(manejadorSubmit);
    $('#btnBorrar').click(manejadorborrar);
    $('#btnLimpiar').click(limpiarFormulario);
    $('#selTipo').change(traerObjetos);
}

//modificar segun objeto
function manejadorSubmit(e) {
    e.preventDefault();
    let legislador = obtenerObjeto(e.target);
    if (legislador.id == 0) {
        altaObjeto(legislador);
    }
    else {
        modificarObjeto(legislador);
    }
    limpiarFormulario();
}

//mofificar segun objeto
function manejadorborrar() {
    let id = parseInt($('#id').val());
    bajaObjeto(id);
    limpiarFormulario();
}

//modificar segun objeto
function obtenerObjeto(frm, conId) {
    let id = 0;
    let nombre;
    let apellido;
    let edad;
    let email;
    let sexo;
    let tipo;
    id = parseInt($('#id').val());
    nombre = $('#nombre').val();
    apellido = $('#apellido').val();
    edad = parseInt($('#edad').val());
    email = $('#email').val();
    if ($('#femenino').prop('checked')) {
        sexo = $('#femenino').val();
    }
    else {
        sexo = $('#masculino').val();
    }
    if ($('#diputado').prop('checked')) {
        tipo = $('#diputado').val();
    }
    else {
        tipo = $('#senador').val();
    }
    return new Legislador(id, nombre, apellido, edad, email, sexo, tipo);
}

//modificar segun objeto
function limpiarFormulario() {
    $('#id').val(0);
    $('#id').prop('hidden', true);
    $('[name="labelId"]').prop('hidden', true);
    $('#nombre').val('');
    $('#apellido').val('');
    $('#edad').val(18);
    $('#email').val('');
    $('#femenino').prop('checked', true);
    $('#diputado').prop('checked', true);
    $('#btnCrear').val('Cargar');
    $('#btnBorrar').prop('hidden', true);
}

//modificar srgun objeto
function traerValores(e) {
    let tr = e.target.parentElement;
    let nodos = tr.childNodes;
    $('#id').val(nodos[0].innerText);
    $('#id').prop('hidden', false);
    $('[name="labelId"]').prop('hidden', false);
    $('#nombre').val(nodos[1].innerText);
    $('#apellido').val(nodos[2].innerText);
    $('#edad').val(nodos[3].innerText);
    $('#email').val(nodos[4].innerText);
    if (nodos[5].innerText === 'Femenino') {
        $('#femenino').prop('checked', true);
    }
    else {
        $('#masculino').prop('checked', true);
    }
    if (nodos[6].innerText === 'Diputado') {
        $('#diputado').prop('checked', true);
    }
    else {
        $('#senador').prop('checked', true);
    }
    $('#btnCrear').val('Modificar');
    $('#btnBorrar').prop('hidden', false);
}

