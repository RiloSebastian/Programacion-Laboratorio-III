function filtrarObjetos(array) {
    let nuevoObjeto = array;
    nuevoObjeto = filtrarValorSelect(nuevoObjeto,'tipo',$('#selTipo option:selected').val(),'Todos');
    let promedioEdad = obtenerPromedio(nuevoObjeto,'edad');
    let procentajeMujeres = obtenerPorcentaje(nuevoObjeto,'sexo','Femenino');
    $('#promedioEdad').val(promedioEdad);
    $('#procentajeMujeres').val(procentajeMujeres);
    return nuevoObjeto;
}

function mascaras() {
    let checkColumna = $('#filtroColumnas :checkbox').map(function () { return $(this).val(); }).get();
    for (i of checkColumna) {
        if ($('#filtroColumnas :checkbox[value="' + i + '"]').prop('checked')) {
            $('#tabla [value="' + i + '"]').prop('hidden', false);
        }
        else {
            $('#tabla [value="' + i + '"]').prop('hidden', true);
        }
    }
}

// ejemplo: filtrarValorSelect(nuevoObjeto,'transaccion',$('#selTransaccion option:selected').val(),'Todos');
function filtrarValorSelect(arrayObjeto, campoObjeto, valorSelect, valorNoFiltrar) {
    if (valorSelect != valorNoFiltrar) {
        nuevoObjeto = arrayObjeto.filter(elemento => {
            if (campoObjeto in elemento && elemento[campoObjeto] == valorSelect) {
                return true;
            }
            return false;
        }).unique();
        return nuevoObjeto;
    }
    else {
        return arrayObjeto;
    }
}

//ejemplo: obtenerPorcentaje(nuevoObjeto,'transaccion','venta');
function obtenerPorcentaje(arrayObjeto, campoObjeto, stringValor) {
    let cantidadValidos = arrayObjeto.filter(elemento => {
        if (campoObjeto in elemento && elemento[campoObjeto] === stringValor) {
            return true;
        }
        return false;
    }).length
    if (isNaN(cantidadValidos)) {
        return 0;
    }    
    return ((cantidadValidos / arrayObjeto.length) * 100);
}

//ejemplo: obtenerPromedio(nuevoObjeto,'precio');
function obtenerPromedio(arrayObjeto, campoObjeto) {
    let promedioPrecio = arrayObjeto.map(elemento => {
        if (campoObjeto in elemento) {
            return elemento[campoObjeto];
        }
    }).reduce((suma, precio, indice, array) => (suma + precio) / array.length, 0);
    return promedioPrecio;
}

Array.prototype.unique = function () {
    return [...new Set(this)];
}
















//no!...funciona, pero mucho quilombo
/*function actualizarFiltros() {


    nuevoObjeto = nuevoObjeto.map(elemento => {
        for (i of checkColumna) {
            delete (elemento[i]);
        }
        return elemento;
    }).unique();
    let chboxValores = $('#mascarasTabla :input[type=checkbox]');
    chboxValores = chboxValores.length;
    for (i = 0; i < chboxValores; i++) {
        $('input[type=checkbox][value=' + i + ']').change(checkboxMarcado);
    }
    $('#btnFiltrar').click(filtrarAnuncios);
}

function checkboxMarcado() {
    if ($(this).prop('checked')) {
        mostrarColumna($(this).val(), true);
    } else {
        mostrarColumna($(this).val(), false);
    }
}

function mostrarColumna(idNodoColumna, mostrar) {
    let filas = $('tr');
    if (mostrar) {
        for (i = 0; i < filas.length; i++) {
            let nodo = filas[i].childNodes;
            $(nodo[idNodoColumna]).prop('hidden', false);
        }
    }
    else {
        for (i = 0; i < filas.length; i++) {
            let nodo = filas[i].childNodes;
            $(nodo[idNodoColumna]).prop('hidden', true);
        }
    }
}

function filtrarAnuncios()
{
    let filas = $('tr');
    if(!$('#filtroVenta').prop('checked'))
    {

    }
}*/