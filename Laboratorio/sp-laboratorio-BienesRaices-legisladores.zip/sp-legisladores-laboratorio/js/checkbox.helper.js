function generarMascarasDeTabla() {
    if ($('#filtroColumnas').prop('innerHTML') === '') {
        $('#filtro').prop('hidden',false);
        let cabeceras = $('#tabla th').map(function () { return $(this).prop('textContent'); }).get();
        let fieldset = document.createElement('fieldset');
        fieldset.setAttribute('class', "form-group mt-3 mb-3");
        let div1 = document.createElement('div');
        div1.setAttribute('class', "form-group");
        let div2 = document.createElement('div');
        div2.setAttribute('id', "mascarasTabla");
        for (valor of cabeceras) {
            let div3 = document.createElement('div');
            div3.setAttribute('class', "form-check form-check-inline");
            let label = document.createElement('label');
            label.setAttribute('class', "form-check-label");
            label.setAttribute('for', "cbox-" + valor);
            label.textContent = valor;
            let box = document.createElement('input');
            box.setAttribute('type', 'checkbox');
            box.setAttribute('class', 'form-check-input');
            box.setAttribute('id', "cbox-" + valor);
            box.setAttribute('value', valor);
            box.checked = true;
            $(box).change(mascaras);
            div3.appendChild(box);
            div3.appendChild(label)
            div2.appendChild(div3);
        }
        div1.appendChild(div2);
        fieldset.appendChild(div1);
        $('#filtroColumnas').append(fieldset);
    }
}