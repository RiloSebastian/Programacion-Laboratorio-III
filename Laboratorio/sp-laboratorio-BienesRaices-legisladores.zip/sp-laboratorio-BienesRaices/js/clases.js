"use strict";
var Anuncio = /** @class */ (function () {
    function Anuncio(id, titulo, descripcion, transaccion, precio, num_wc, num_dormitorios, num_estacionamientos) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.transaccion = transaccion;
        this.precio = precio;
        this.num_wc = num_wc;
        this.num_dormitorios = num_dormitorios;
        this.num_estacionamientos = num_estacionamientos;
    }
    Object.defineProperty(Anuncio.prototype, "Id", {
        get: function () { return this.id; },
        set: function (e) { this.id = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Titulo", {
        get: function () { return this.titulo; },
        set: function (e) { this.titulo = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Descripcion", {
        get: function () { return this.descripcion; },
        set: function (e) { this.descripcion = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Transaccion", {
        get: function () { return this.transaccion; },
        set: function (e) { this.transaccion = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Precio", {
        get: function () { return this.precio; },
        set: function (e) { this.precio = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Num_wc", {
        get: function () { return this.num_wc; },
        set: function (e) { this.num_wc = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Num_dormitorios", {
        get: function () { return this.num_dormitorios; },
        set: function (e) { this.num_dormitorios = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Num_estacionamientos", {
        get: function () { return this.num_estacionamientos; },
        set: function (e) { this.num_estacionamientos = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    return Anuncio;
}());
//# sourceMappingURL=clases.js.map