function crearTabla(array) {
    $('#tabla').prop('innerHTML','');
    let tabla = document.createElement('table');
    tabla.setAttribute('class', "table table-hover table-bordered table-responsive-xl");
    let theader = document.createElement('thead');
    theader.setAttribute('class', "thead-dark");
    let columnaHeader = document.createElement('tr');
    for (elemento in array[0]) {
        let celdaHeader = document.createElement('th');
        celdaHeader.setAttribute('scope', "col");
        celdaHeader.setAttribute('value', elemento);
        celdaHeader.textContent = elemento;
        columnaHeader.appendChild(celdaHeader);
    }
    theader.appendChild(columnaHeader);
    tabla.appendChild(theader);
    for (i in array) {
        fila = document.createElement('tr');
        fila.setAttribute('class', "table-primary");
        let objeto = array[i];
        for (j in objeto) {
            let celda = document.createElement('td');
            let dato = document.createTextNode(objeto[j]);
            celda.setAttribute('value', j);
            celda.appendChild(dato);
            $(celda).click(traerValores);
            fila.appendChild(celda);
        }
        tabla.appendChild(fila);
    }
    $('#tabla').append(tabla);
    generarMascarasDeTabla();
}