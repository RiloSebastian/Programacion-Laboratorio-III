window.addEventListener('load', inicializarManejadores);
window.addEventListener('load', traerAnuncios);

function inicializarManejadores() {
    $('#frm').submit(manejadorSubmit);
    $('#btnBorrar').click(manejadorborrar);
    $('#btnLimpiar').click(limpiarFormulario);
}

function manejadorSubmit(e) {
    e.preventDefault();
    let anuncio = obtenerAnuncio(e.target);
    if (anuncio.id == 0) {
        altaAnuncio(anuncio);
    } else {
        modificarAnuncio(anuncio);
    }
    limpiarFormulario();
}

function manejadorborrar() {
    let id = $('#idAnuncio').val();
    bajaAnuncio(id);
    limpiarFormulario();
}

function obtenerAnuncio(frm, conId) {
    let id = 0;
    let titulo;
    let transaccion;
    let descripcion;
    let precio;
    let num_wc;
    let num_dormitorios;
    let num_estacionamientos;

    for (element of frm.elements) {
        switch (element.name) {
            case 'idAnuncio':
                id = parseInt(element.value);
                break;
            case 'titulo':
                titulo = element.value;
                break;
            case 'tipo':
                if (element.checked === true) {
                    transaccion = element.value;
                }
                break;
            case 'descripcion':
                descripcion = element.value;
                break;
            case 'precio':
                precio = $('#selMoneda :selected').val() + '$ ' + element.value;
                break;
            case 'banos':
                num_wc = parseInt(element.value);
            case 'dormitorios':
                num_dormitorios = parseInt(element.value);
                break;
            case 'cocheras':
                num_estacionamientos = parseInt(element.value);
                break;
        }
    }
    return new Anuncio(id, titulo, descripcion, transaccion, precio, num_wc, num_dormitorios, num_estacionamientos);
}

function limpiarFormulario() {
    $('#idAnuncio').val('');
    $('#idAnuncio').prop('hidden', true);
    $('#titulo').val('');
    $('#descripcion').val('');
    $('#venta').prop('checked', true);
    $('#precio').val(0);
    $('#banos').val(1);
    $('#selMoneda').val($('#pesoArgentino').val());
    $('#dormitorios').val(1);
    $('#cocheras').val(1);
    $('#btnCrear').prop('textContent', 'Crear');
    $('#btnBorrar').prop('hidden', true);
}

function traerValores(e) {
    let tr = e.target.parentElement;
    let nodos = tr.childNodes;
    $('#idAnuncio').val(nodos[0].innerText);
    $('#idAnuncio').prop('hidden', false);
    $('#idAnuncio').prop('disabled', false);
    $('#titulo').val(nodos[1].innerText);
    if (nodos[2].innerText === 'Venta') {
        $('#venta').prop('checked', true);
    } else {
        $('#alquiler').prop('checked', true);
    }
    $('#descripcion').val(nodos[3].innerText);
    let arreglo = nodos[4].innerText.split(',');
    let select = arreglo[0].substr(0, 3);
    $('#selMoneda').val($('[value="' + select + '"]').val());
    $('#precio').val(parseInt(arreglo[1]));
    $('#banos').val(nodos[5].innerText);
    $('#dormitorios').val(nodos[7].innerText);
    $('#cocheras').val(nodos[6].innerText);
    $('#btnCrear').prop('textContent', 'Modificar');
    $('#btnBorrar').prop('hidden', false);
}