function traerAnuncios() {
    let datos = [];
    $('#divTabla').prop('innerHTML', '<img src="./img/831.gif" alt="spinner">');
    $.getJSON("http://localhost:3000/traerAnuncios", function(resp, status) {
        for (var i = 0; i < resp.data.length; i++) {
            let arreglo = resp.data[i].precio.split(' ');
            datos.push(new Anuncio(resp.data[i].id, resp.data[i].titulo, resp.data[i].descripcion,
                resp.data[i].transaccion, arreglo,
                resp.data[i].num_wc, resp.data[i].num_dormitorio, resp.data[i].num_estacionamiento));
        }
        let tabla = crearTabla(datos);
        $('#divTabla').prop('innerHTML', '');
        $('#divTabla').append(tabla);
    });
}

function altaAnuncio(anuncio) {
    console.log('entro alta');
    $('#divTabla').prop('innerHTML', '<img src="./img/831.gif" alt="spinner">');
    $.post("http://localhost:3000/altaAnuncio", anuncio, function() {
        traerAnuncios();
    });
}

function bajaAnuncio(id) {
    $('#divTabla').prop('innerHTML', '<img src="./img/831.gif" alt="spinner">');
    $.post("http://localhost:3000/bajaAnuncio", `id=${id}`, function() {
        traerAnuncios();
    });
}

function modificarAnuncio(anuncio) {
    $('#divTabla').prop('innerHTML', '<img src="./img/831.gif" alt="spinner">');
    $.post("http://localhost:3000/modificarAnuncio", anuncio, function() {
        traerAnuncios();
    });
}