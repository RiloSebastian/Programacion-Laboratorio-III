function Anuncio(id, titulo, descripcion, tipo, precio, num_wc, num_dormitorios, num_estacionamiento) {
    this.id = id;
    this.titulo = titulo;
    this.transaccion = tipo;
    this.descripcion = descripcion;
    this.precio = precio;
    this.num_wc = num_wc;
    this.num_estacionamiento = num_estacionamiento;
    this.num_dormitorio = num_dormitorios;
}