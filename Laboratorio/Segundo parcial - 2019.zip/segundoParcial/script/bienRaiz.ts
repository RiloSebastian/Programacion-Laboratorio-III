/// <reference path="anuncio.ts" />

class BienRaiz extends Anuncio {

    private transaccion: ETRansaccion;

    constructor(id: number, titulo: string, descripcion: string, transaccion: ETRansaccion,
        precio: number, num_wc: number, num_dormitorios: number, num_estacionamientos: number) {

        super(id, titulo, descripcion, precio, num_wc, num_dormitorios, num_estacionamientos);
        this.transaccion = transaccion;

    }

    get Transaccion(): ETRansaccion { return this.transaccion; };
    set Transaccion(e: ETRansaccion) { this.transaccion = e; };
}
