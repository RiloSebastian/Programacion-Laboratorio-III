class Anuncio{
    private id:number;
    private titulo:string;
    private descripcion:string;
    private precio:number;
    private num_wc:number;
    private num_dormitorios:number;
    private num_estacionamientos:number;

    constructor(id:number,titulo:string,descripcion:string,
        precio:number,num_wc:number,num_dormitorios:number,num_estacionamientos:number){
            this.id =id;
            this.titulo =titulo;
            this.descripcion =descripcion;
            this.precio =precio;
            this.num_wc =num_wc;
            this.num_dormitorios =num_dormitorios;
            this.num_estacionamientos =num_estacionamientos;
        }

        get Id():number{return this.id;};
        set Id(e:number){this.id = e;};

        get Titulo():string{return this.titulo;};
        set Titulo(e:string){this.titulo = e;};

        get Descripcion():string{return this.descripcion;};
        set Descripcion(e:string){this.descripcion = e;};

        get Precio():number{return this.precio;};
        set Precio(e:number){this.precio = e;};

        get Num_wc():number{return this.num_wc;};
        set Num_wc(e:number){this.num_wc = e;};

        get Num_dormitorios():number{return this.num_dormitorios;};
        set Num_dormitorios(e:number){this.num_dormitorios = e;};

        get Num_estacionamientos():number{return this.num_estacionamientos;};
        set Num_estacionamientos(e:number){this.num_estacionamientos = e;};

}

enum ETRansaccion{
    Venta,
    Alquiler
}

