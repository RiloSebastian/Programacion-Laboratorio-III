window.addEventListener('load', inicializarManejadores);
window.addEventListener('load', traerAnuncios);

function inicializarManejadores() {
    $('#frm').submit(manejadorSubmit);
    $('#btnBorrar').click(manejadorborrar);
    $('#btnLimpiar').click(limpiarFormulario);
    $('#selTransaccion').change(traerAnuncios);
}

function manejadorSubmit(e) {
    e.preventDefault();
    let anuncio = obtenerAnuncio(e.target);
    if (anuncio.id == 0) {
        altaAnuncio(anuncio);
    } else {
        modificarAnuncio(anuncio);
    }
    limpiarFormulario();
}

function manejadorborrar() {
    let id = parseInt($('#id').val());
    bajaAnuncio(id);
    limpiarFormulario();
}

function obtenerAnuncio(frm, conId) {
    let id = 0;
    let titulo;
    let transaccion;
    let descripcion;
    let precio;
    let num_wc;
    let num_dormitorios;
    let num_estacionamientos;
    id = parseInt($('#id').val());
    titulo = $('#titulo').val();
    descripcion = $('#descripcion').val();
    if ($('#venta').prop('checked')) {
        transaccion = $('#venta').val();
    } else {
        transaccion = $('#alquiler').val();
    }
    precio = parseInt($('#precio').val());
    num_wc = parseInt($('#num_wc').val());
    num_dormitorios = parseInt($('#num_dormitorios').val());
    num_estacionamientos = parseInt($('#num_estacionamientos').val());

    return new BienRaiz(id, titulo, descripcion, transaccion, precio, num_wc, num_dormitorios, num_estacionamientos);
}

function limpiarFormulario() {
    $('#id').val(0);
    $('#id').prop('hidden', true);
    $('[name="labelId"]').prop('hidden', true);
    $('#titulo').val('');
    $('#descripcion').val('');
    $('#venta').prop('checked', true);
    $('#precio').val(0);
    $('#num_wc').val(1);
    $('#num_dormitorios').val(1);
    $('#num_estacionamientos').val(1);
    $('#btnCrear').val('Cargar');
    $('#btnBorrar').prop('hidden', true);
}

function traerValores(e) {
    let tr = e.target.parentElement;
    let nodos = tr.childNodes;
    $('#id').val(nodos[0].innerText);
    $('#id').prop('hidden', false);
    $('[name="labelId"]').prop('hidden', false);
    $('#titulo').val(nodos[1].innerText);
    $('#descripcion').val(nodos[2].innerText);
    if (nodos[7].innerText === 'Venta') {
        $('#venta').prop('checked', true);
    } else {
        $('#alquiler').prop('checked', true);
    }
    $('#precio').val(nodos[3].innerText);
    $('#num_wc').val(nodos[4].innerText);
    $('#num_dormitorios').val(nodos[5].innerText);
    $('#num_estacionamientos').val(nodos[6].innerText);
    $('#btnCrear').val('Modificar');
    $('#btnBorrar').prop('hidden', false);
}