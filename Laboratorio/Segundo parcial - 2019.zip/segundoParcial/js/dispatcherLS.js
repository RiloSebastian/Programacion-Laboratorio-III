function traerAnuncios() {
   let array = obtenerArray();
   array = filtrarAnuncios(array);
   if (array.length > 0) {
      let tabla = crearTabla(array);
   }
   else {
      $('#tabla').prop('innerHTML', '');
      $('#filtroColumnas').prop('innerHTML', '');
   }
}

function altaAnuncio(anuncio) {
   let array = obtenerArray();
   let id = generarID(array);
   anuncio.id = id;
   array.push(anuncio);
   localStorage.setItem('Anuncios', JSON.stringify(array));
   traerAnuncios();
}

function modificarAnuncio(anuncio) {
   let array = obtenerArray();
   for (i in array) {
      if (array[i].id === anuncio.id) {
         array[i] = anuncio;
      }
   }
   localStorage.setItem('Anuncios', JSON.stringify(array));
   traerAnuncios();
}

function bajaAnuncio(id) {
   let array = obtenerArray();
   let nuevoArray = [];
   for (i in array) {
      if (array[i].id === id) {
         nuevoArray = array.filter(element => element.id != id);
      }
   }
   localStorage.setItem('Anuncios', JSON.stringify(nuevoArray));
   traerAnuncios();
}

function obtenerArray() {
   let array = localStorage.getItem('Anuncios');
   if (array == null || array === '') {
      array = [];
   }
   else {
      array = JSON.parse(array);
   }
   return array;
}

function generarID(array) {
   let id = 0;
   if (array.length > 0) {
      for (i in array) {
         if (array[i].id >= id) {
            id = array[i].id;
         }
      }
   }
   return id + 1;
}