"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Anuncio = /** @class */ (function () {
    function Anuncio(id, titulo, descripcion, precio, num_wc, num_dormitorios, num_estacionamientos) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.precio = precio;
        this.num_wc = num_wc;
        this.num_dormitorios = num_dormitorios;
        this.num_estacionamientos = num_estacionamientos;
    }
    Object.defineProperty(Anuncio.prototype, "Id", {
        get: function () { return this.id; },
        set: function (e) { this.id = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Titulo", {
        get: function () { return this.titulo; },
        set: function (e) { this.titulo = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Descripcion", {
        get: function () { return this.descripcion; },
        set: function (e) { this.descripcion = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Precio", {
        get: function () { return this.precio; },
        set: function (e) { this.precio = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Num_wc", {
        get: function () { return this.num_wc; },
        set: function (e) { this.num_wc = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Num_dormitorios", {
        get: function () { return this.num_dormitorios; },
        set: function (e) { this.num_dormitorios = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    Object.defineProperty(Anuncio.prototype, "Num_estacionamientos", {
        get: function () { return this.num_estacionamientos; },
        set: function (e) { this.num_estacionamientos = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    return Anuncio;
}());
var ETRansaccion;
(function (ETRansaccion) {
    ETRansaccion[ETRansaccion["Venta"] = 0] = "Venta";
    ETRansaccion[ETRansaccion["Alquiler"] = 1] = "Alquiler";
})(ETRansaccion || (ETRansaccion = {}));
/// <reference path="anuncio.ts" />
var BienRaiz = /** @class */ (function (_super) {
    __extends(BienRaiz, _super);
    function BienRaiz(id, titulo, descripcion, transaccion, precio, num_wc, num_dormitorios, num_estacionamientos) {
        var _this = _super.call(this, id, titulo, descripcion, precio, num_wc, num_dormitorios, num_estacionamientos) || this;
        _this.transaccion = transaccion;
        return _this;
    }
    Object.defineProperty(BienRaiz.prototype, "Transaccion", {
        get: function () { return this.transaccion; },
        set: function (e) { this.transaccion = e; },
        enumerable: true,
        configurable: true
    });
    ;
    ;
    return BienRaiz;
}(Anuncio));
//# sourceMappingURL=clases.js.map