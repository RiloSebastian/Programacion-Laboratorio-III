var frm;
let anuncios= Array();

window.addEventListener("load",inicializarManejadores);

function inicializarManejadores(){

    frm= document.forms[0];

    frm.addEventListener("submit",manejadorSubmit);

    
}

function manejadorSubmit(e){
    e.preventDefault();

    let nuevaAnuncio= obtenerAnuncio(e.target);
    Anuncios.push(nuevaAnuncio);  
    document.getElementById("tabla").innerHTML = "";
    document.getElementById("tabla").appendChild(crearTabla(Anuncios));
    console.log(Anuncios);
}


function obtenerAnuncio(frm){
    let id;
    let titulo;
    let transaccion;
    let descripcion;
    let numBaños;
    let numGarage;
    let numHabitacion;

    for(elemento of frm.elements){

        switch(elemento.name){

            case "id":
                id = elemento.value;
                break;

            case "titulo":
                titulo = elemento.value ;
                break;

            case "transaccion":
            if(elemento.checked){

                transaccion = elemento.value;
            }
             break;

            case "vacunado":
                descripcion = elemento.value;
                break;

            case "castrado":
                numBaños = parseInt(elemento.value);
                break;

            case "desparasitado":
                numGarage = parseInt(elemento.value);
                break;

            case "alimento":
                numHabitacion = parseInt(elemento.value);
                break;

        }
        
    }
    return new Anuncio(id,titulo,descripcion,transaccion,precio,numBaños,numGarage,numHabitacion);
}