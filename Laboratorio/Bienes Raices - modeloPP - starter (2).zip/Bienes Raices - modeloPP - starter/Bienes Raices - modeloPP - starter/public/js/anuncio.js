function Anuncio(id, titulo, descripcion, transaccion, precio, numBaños, numGarage, numHabitacion){
    this.id=id;
    this.titulo= titulo;
    this.descripcion= descripcion;
    this.transaccion= transaccion;
    this.precio= precio;
    this.numBaños= numBaños;
    this.numGarage= numGarage;
    this.numHabitacion= numHabitacion;

}