"use strict";
//forma de declarar una variable con tipo -- el '|' nos deja darle a una variable mas de un posible tipo de valor
var mensaje = 'hola';
console.log(mensaje);
//array
var vector = [1, 2, 3, 4];
//tupla -- el equivalente a una coleccion list de c#
var tupla = [1, 'ironman'];
//enum -- mismo concepto que el de c#
var Eheroe;
(function (Eheroe) {
    Eheroe[Eheroe["xmen"] = 0] = "xmen";
    Eheroe[Eheroe["Avenger"] = 1] = "Avenger";
})(Eheroe || (Eheroe = {}));
console.log('enum:');
//muestra valor numerico
console.log(Eheroe.Avenger);
console.log(Eheroe['Avenger']);
//muestra clave
console.log(Eheroe[Eheroe.Avenger]);
//muestra todos los elementos del enum: claves y valores numericos
for (var key in Eheroe) {
    console.log(key);
}
//funciones --si pones ? entre el argumento y :'tipo' indica que el argumento es opcional o si luego pones '=valor' indica un valor por defecto
var funcionEnviarMision = function (heroe) {
    return heroe + ' enviado';
};
var retorno = funcionEnviarMision('Spiderman');
console.log('funcion:');
console.log(retorno);
//referenciar archivos
/// <reference path="./hello.ts" />
var adios = 'adios';
console.log(adios);
//# sourceMappingURL=output.js.map