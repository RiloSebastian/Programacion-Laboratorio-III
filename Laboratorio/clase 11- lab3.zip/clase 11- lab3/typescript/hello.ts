//forma de declarar una variable con tipo -- el '|' nos deja darle a una variable mas de un posible tipo de valor
let mensaje: string | number = 'hola';
console.log(mensaje);

//array

let vector:number[] = [1,2,3,4];

//tupla -- el equivalente a una coleccion list de c#
let tupla:[number,string] = [1,'ironman']

//enum -- mismo concepto que el de c#
enum Eheroe{
    xmen,
    Avenger
}
console.log('enum:')
//muestra valor numerico
console.log(Eheroe.Avenger);
console.log(Eheroe['Avenger']);
//muestra clave
console.log(Eheroe[Eheroe.Avenger]);

//muestra todos los elementos del enum: claves y valores numericos
for(let key in Eheroe){
    console.log(key);
}

//funciones --si pones ? entre el argumento y :'tipo' indica que el argumento es opcional o si luego pones '=valor' indica un valor por defecto

let funcionEnviarMision = function(heroe?:string):string{
    return heroe + ' enviado';
}

let retorno:string = funcionEnviarMision('Spiderman');
console.log('funcion:');
console.log(retorno);