$(function(){

    //selecciona por id
    console.log($("#botonEnviar"));

    //selecciona por tag
    console.log($("p"));

    //seleccion por clase
    console.log($("p.rojo"));

    console.log($("p:last"));

    //selecciono por atributo
    console.log($("p[class=rojo]"));

})