$(function(){
    $("#botonEnviar").click(function(){
       // alert("hiciste click en el boton");
    });

    //una forma de agregar varios manejadores 
    $("p").hover(function(e){
        console.log("pasaste arriba");
    },
    function(e){
        console.log("saliste");
    })

    //otra forma de agregar manejadores
    $("p.rojo").on("click",function(){

    })

    //crear varios manejadores
    $("p.rojo").on({
        "click": function(){
            console.log("haz dado click al parrafo rojo");
        },
        "mouseenter":function(){
            console.log("hola");
        },
        "mouseleave":function(){
            console.log("chau");
        }
    })
    //.off quita manejadores
    $("p.rojo").off("click");
})