$(function(){
    $("#botonEnviar").click(function(){
        /*
        console.log($("p.rojo").text());
        console.log($("p.rojo").html());
        console.log($("#botonEnviar").val());
        console.log($("#botonEnviar").attr("id"));
        */
    })

    $("#botonCambiar").click(function(){
       
       /* $("p.rojo").text("este es el nuevo texto del parrafo rojo");
        $("p:last").html("<strong>este parrafo va en negrita</strong>");
        $("p:last").html(function(i,prevHTML){
            return prevHTML + " agrego este html";
        })

        $("#botonCambiar").val("nuevo Cambiar");

        $("#botonCambiar").attr("class","azul");

        $("#botonEnviar").attr({
            "class":"azul",
            "miValor":"algo"
        })

        $("#botonEnviar").attr("class",function(i,prevValue){
            console.log("clase anterior: "+ prevValue);
            return "rojo";
        })*/

        var boton = $("<input>").val("nuevo Boton").attr("type","button").addClass("azul").css("margin","100px");
       // $("body").prepend(boton); al principio del body
        //$("#botonCambiar").after(boton); antes de botonCambiar
        //$("#botonCambiar").before(boton); depues de botonCambiar
        $("body").append(boton); //al final del body

        $("#botonEnviar").toggleClass("azul");
        console.log($("input:last").css("margin"));
        
    })


})