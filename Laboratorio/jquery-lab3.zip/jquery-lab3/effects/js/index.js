$(function(){


    $("p:last").hide(4000,function(){
        $("p:last").show(4000);
    })
    
    $("#botonEnviar").toggle(4000,function(){
        $("#botonEnviar").toggle(4000);
    })

    $("#botonEnviar").click(function(){

        $("#botonEnviar").animate(function(){
            
            height: '+=50px',
            width: '+=50px';

        },5000).animate(function(){
            height: '-=50px',
            width: '-=50px'
        })

    })
})