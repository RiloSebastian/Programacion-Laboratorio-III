function Anuncio(id, titulo, descripcion, transaccion, precio, num_Wc, num_estacionamiento, num_dormitorios){
    this.id=id;
    this.titulo= titulo;
    this.descripcion= descripcion;
    this.transaccion= transaccion;
    this.precio= precio;
    this.num_Wc= num_Wc;
    this.num_estacionamiento= num_estacionamiento;
    this. num_dormitorios=  num_dormitorios;

}

function cargarDatos(manejador){
    datos=[];
    $.getJSON("http://localhost:3000/traerAnuncios",function(resp,status){
        
    })
}