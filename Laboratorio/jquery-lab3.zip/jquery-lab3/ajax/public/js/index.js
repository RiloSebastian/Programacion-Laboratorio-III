$(function(){
    $("#btnCargar").click(function(){
        //llamar a cargar
        var impresion_consola= function(){
            console.log(datos);
        }
        cargarDatos(impresion_consola);
    })
})