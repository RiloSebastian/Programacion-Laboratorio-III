//referenciar archivos
/// <reference path="./hello.ts" />

let adios: string = 'adios';
console.log(adios);