//forma de declarar una variable con tipo -- el '|' nos deja darle a una variable mas de un posible tipo de valor
let mensaje: string | number = "hola";
console.log(mensaje);

//array

let vector: number[] = [1, 2, 3, 4];

//tupla -- el equivalente a una coleccion list de c#
let tupla: [number, string] = [1, "ironman"];

//enum -- mismo concepto que el de c#
enum Eheroe {
  xmen,
  Avenger
}
console.log("enum:");
//muestra valor numerico
console.log(Eheroe.Avenger);
console.log(Eheroe["Avenger"]);
//muestra clave
console.log(Eheroe[Eheroe.Avenger]);

//muestra todos los elementos del enum: claves y valores numericos
for (let key in Eheroe) {
  console.log(key);
}

//funciones --si pones ? entre el argumento y :'tipo' indica que el argumento es opcional o si luego pones '=valor' indica un valor por defecto

let funcionEnviarMision = function(heroe?: string): string {
  return heroe + " enviado";
};

let retorno: string = funcionEnviarMision("Spiderman");
console.log("funcion:");
console.log(retorno);

//parametros REST

let funccionEnviarmision2 = function(...heroes: string[]): void {
  for (let i = 0; i < heroes.length; i++) {
    console.log(heroes[i] + " enviado");
  }
};

funccionEnviarmision2("batman", "ironman", "hulk");

//funcion flecha
let funcionenviarmision3 = (heroe: string = "heroe"): string => {
  return heroe + " enviado. mision 3";
};
console.log(funcionenviarmision3());

//tipo de objeto
let flash: {
  nombre: string;
  edad: number;
  poderes: string[];
  getNombre: () => string;
} = {
  nombre: "barry allen",
  edad: 26,
  poderes: ["corre", "viaja en el tiempo"],
  getNombre() {
    return this.nombre;
  }
};

//tipo personalizado

type heroe = {
  nombre: string;
  edad: number;
  poderes?: string[];
  getNombre: () => string;
};
let ironman: heroe = {
  nombre: "tony Stark",
  edad: 24,
  getNombre: function() {
    return this.nombre;
  }
};

console.log(ironman.getNombre());

//interfaces
interface IHeroe {
  nombre: string;
  poderes?: string[];
  mostrar?(): string;
}

let wolwerine: IHeroe = {
  nombre: "james"
};

console.log(wolwerine.nombre);

//interfaces en clase

class Avenger implements IHeroe {
  nombre: string = "un avenger";
}

class Mutante implements IHeroe {
  nombre: string = "un mutante";
}

let unAvenger = new Avenger();
let unmutante = new Mutante();

console.log("unAvenger: " + unAvenger.nombre);
console.log("unMutante: " + unmutante.nombre);

//interfaces en funcion

interface IfuncionDosNumeros {
  (num1: number, num2: number): number;
}

let miFuncion: IfuncionDosNumeros;
miFuncion = (num1, num2) => num1 + num2;

console.log(miFuncion(1, 2));

class avenger2 implements IHeroe {
  nombre: string = "un Avenger";

  constructor(nombre: string) {
    this.nombre = nombre;
  }
}

let av2 = new avenger2("hulk");

console.log("clase: " + av2.nombre);

//clase con atrb privado

class avenger3 {
  private _nombre: string = "un avenger";
  private _edad: number = 30;

  constructor(nombre: string) {
    this._nombre = nombre;
  }

  get edad(): number {
    return this._edad;
  }
  set edad(e: number) {
    this._edad = e;
  }

  public mostrar = () => this._nombre;
}

let av3 = new avenger3("ironman");
console.log("clase 3 : " + av3.mostrar());

av3.edad = 38;
console.log("av3 edad: " + av3.edad);

//clases con campos estaticos

class xmen {
  static nombre_de_clase = "xmen";
}
console.log("nombre de clase forma estatica: " + xmen.nombre_de_clase);

//herencia

class avengerHeredado extends avenger3 {}

let av4 = new avengerHeredado("heredado");
console.log("nombre heredado: " + av4.mostrar());

class avengerHeredado2 extends avenger3 {
  constructor(nombre: string, edad: number) {
    super(nombre);
    this.edad = edad;
  }
}

let av4_2 = new avengerHeredado2("heredado2", 35);
console.log("nombre de heredado2: " + av4_2.mostrar() + " edad: " + av4_2.edad);

//namespaces
namespace funciones {
  export function f1() {
    console.log("yo soy la f1");
  }
  export function f2() {
    console.log("yo soy la f2");
  }
}


funciones.f1();
funciones.f2();

$(function(){
    console.log('ready');
});

$()