"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//forma de declarar una variable con tipo -- el '|' nos deja darle a una variable mas de un posible tipo de valor
var mensaje = "hola";
console.log(mensaje);
//array
var vector = [1, 2, 3, 4];
//tupla -- el equivalente a una coleccion list de c#
var tupla = [1, "ironman"];
//enum -- mismo concepto que el de c#
var Eheroe;
(function (Eheroe) {
    Eheroe[Eheroe["xmen"] = 0] = "xmen";
    Eheroe[Eheroe["Avenger"] = 1] = "Avenger";
})(Eheroe || (Eheroe = {}));
console.log("enum:");
//muestra valor numerico
console.log(Eheroe.Avenger);
console.log(Eheroe["Avenger"]);
//muestra clave
console.log(Eheroe[Eheroe.Avenger]);
//muestra todos los elementos del enum: claves y valores numericos
for (var key in Eheroe) {
    console.log(key);
}
//funciones --si pones ? entre el argumento y :'tipo' indica que el argumento es opcional o si luego pones '=valor' indica un valor por defecto
var funcionEnviarMision = function (heroe) {
    return heroe + " enviado";
};
var retorno = funcionEnviarMision("Spiderman");
console.log("funcion:");
console.log(retorno);
//parametros REST
var funccionEnviarmision2 = function () {
    var heroes = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        heroes[_i] = arguments[_i];
    }
    for (var i = 0; i < heroes.length; i++) {
        console.log(heroes[i] + " enviado");
    }
};
funccionEnviarmision2("batman", "ironman", "hulk");
//funcion flecha
var funcionenviarmision3 = function (heroe) {
    if (heroe === void 0) { heroe = "heroe"; }
    return heroe + " enviado. mision 3";
};
console.log(funcionenviarmision3());
//tipo de objeto
var flash = {
    nombre: "barry allen",
    edad: 26,
    poderes: ["corre", "viaja en el tiempo"],
    getNombre: function () {
        return this.nombre;
    }
};
var ironman = {
    nombre: "tony Stark",
    edad: 24,
    getNombre: function () {
        return this.nombre;
    }
};
console.log(ironman.getNombre());
var wolwerine = {
    nombre: "james"
};
console.log(wolwerine.nombre);
//interfaces en clase
var Avenger = /** @class */ (function () {
    function Avenger() {
        this.nombre = "un avenger";
    }
    return Avenger;
}());
var Mutante = /** @class */ (function () {
    function Mutante() {
        this.nombre = "un mutante";
    }
    return Mutante;
}());
var unAvenger = new Avenger();
var unmutante = new Mutante();
console.log("unAvenger: " + unAvenger.nombre);
console.log("unMutante: " + unmutante.nombre);
var miFuncion;
miFuncion = function (num1, num2) { return num1 + num2; };
console.log(miFuncion(1, 2));
var avenger2 = /** @class */ (function () {
    function avenger2(nombre) {
        this.nombre = "un Avenger";
        this.nombre = nombre;
    }
    return avenger2;
}());
var av2 = new avenger2("hulk");
console.log("clase: " + av2.nombre);
//clase con atrb privado
var avenger3 = /** @class */ (function () {
    function avenger3(nombre) {
        var _this = this;
        this._nombre = "un avenger";
        this._edad = 30;
        this.mostrar = function () { return _this._nombre; };
        this._nombre = nombre;
    }
    Object.defineProperty(avenger3.prototype, "edad", {
        get: function () {
            return this._edad;
        },
        set: function (e) {
            this._edad = e;
        },
        enumerable: true,
        configurable: true
    });
    return avenger3;
}());
var av3 = new avenger3("ironman");
console.log("clase 3 : " + av3.mostrar());
av3.edad = 38;
console.log("av3 edad: " + av3.edad);
//clases con campos estaticos
var xmen = /** @class */ (function () {
    function xmen() {
    }
    xmen.nombre_de_clase = "xmen";
    return xmen;
}());
console.log("nombre de clase forma estatica: " + xmen.nombre_de_clase);
//herencia
var avengerHeredado = /** @class */ (function (_super) {
    __extends(avengerHeredado, _super);
    function avengerHeredado() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return avengerHeredado;
}(avenger3));
var av4 = new avengerHeredado("heredado");
console.log("nombre heredado: " + av4.mostrar());
var avengerHeredado2 = /** @class */ (function (_super) {
    __extends(avengerHeredado2, _super);
    function avengerHeredado2(nombre, edad) {
        var _this = _super.call(this, nombre) || this;
        _this.edad = edad;
        return _this;
    }
    return avengerHeredado2;
}(avenger3));
var av4_2 = new avengerHeredado2("heredado2", 35);
console.log("nombre de heredado2: " + av4_2.mostrar() + " edad: " + av4_2.edad);
//namespaces
var funciones;
(function (funciones) {
    function f1() {
        console.log("yo soy la f1");
    }
    funciones.f1 = f1;
    function f2() {
        console.log("yo soy la f2");
    }
    funciones.f2 = f2;
})(funciones || (funciones = {}));
funciones.f1();
funciones.f2();
$(function () {
    console.log('ready');
});
$();
//referenciar archivos
/// <reference path="./hello.ts" />
var adios = 'adios';
console.log(adios);
//# sourceMappingURL=output.js.map