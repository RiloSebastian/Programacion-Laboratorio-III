<?php

function Saludar($nombre){
    echo "Hola $nombre";
}