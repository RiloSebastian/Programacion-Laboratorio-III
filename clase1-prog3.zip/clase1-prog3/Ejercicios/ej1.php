<?php

$nombre="sebastian";
$apellido="rilo";


print("$apellido, $nombre");

?>