<?php

interface IInterface 
{
    //añadir metodo inscribirse y rendir
}

