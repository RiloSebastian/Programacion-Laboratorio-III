<?php
require_once 'clases/alumno.php';

$alumno= new Alumno("pepe",21,10,1);

$alumno->saludar()

?>