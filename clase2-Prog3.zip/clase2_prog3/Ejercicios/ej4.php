<?php

$resultado=0;
$contador = 0;
$i;
for($i = 1; $resultado < 1000; $i++)
{
    $resultado+= $i; 
    $contador++;
}

echo " resultado: $resultado<br/> se sumaron: $contador numeros ";