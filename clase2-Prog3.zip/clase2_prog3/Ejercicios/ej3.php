<?php

$numero1= -3;
$numero2= 15;

$numero3 = $numero1+ $numero2;

echo "$numero1<br/> $numero2<br/> $numero3";



?>