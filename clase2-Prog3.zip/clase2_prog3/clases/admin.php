<?php

interface IInterface 
{
    function inscribirse();
    function rendir(); //añadir metodo inscribirse y rendir
}

