<?php
require_once 'alumno.php';

class Alumno_dao{

    public $vec;

    public function __construct()
    {
        $this->vec=array(new Alumno("fede",30,4,1),new Alumno("pepe",21,10,1),new Alumno("juan",21,8,1));
    }

    public function Listar(){
        
        var_dump($this->vec);
    }

    public function Agregar($valor){
        array_push($this->vec,new Alumno($valor[0],$valor[1],$valor[2],$valor[3]));
        $this->Listar();
    }

    public function Modificar($valor){
        foreach( $this->vec as $alumnos){
            if($valor == $alumnos->legajo){
                $alumnos->Nombre= "---";
                $alumnos->edad= "0";
                $alumnos->Cuatrimestre= "0";
                break;
            }
        }
    }
}

