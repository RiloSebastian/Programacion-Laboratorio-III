<?php
session_start();

//prueba de que funciona. contador por cada peticion
/*
if(!isset($_SESSION["count"])){
    $_SESSION["count"]=0;
}

 echo $_SESSION["count"]+=1;

*/

require_once 'clases/alumno_Dao.php';

$alumno= new alumno_Dao();

if($_SERVER["REQUEST_METHOD"]=="GET")
{
    $alumno->Listar();
}
else if($_SERVER["REQUEST_METHOD"]=="POST")
{
    $valor= array($_GET["nombre"],$_GET["edad"],$_GET["legajo"],$_GET["cuatrimestre"]);

    $alumno->Agregar($valor);
}
else if ($_SERVER["REQUEST_METHOD"]=="PUT") {
    $id= $_GET["legajo"];
    $alumno->Modificar($id);
}
else if ($_SERVER["REQUEST_METHOD"]=="DELETE") {
    $id= $_GET["legajo"];
    $alumno->Borrar($id);
}


//session_unset();
//session_destroy();
?>