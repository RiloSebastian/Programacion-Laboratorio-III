<?php

class controladorOvni
{
    public function AgregarOvniSinFoto($request, $response)
    {
        $body = $request->getParsedBody();
        $body = json_decode($body['json']);
        $alien = new Alien($body->tipo, $body->velocidad, $body->planetaOrigen);
        if($alien->Agregar())
        {
            $mensaje = array('exito' => true, 'mensaje' => 'se ha guardado el objeto con exito');
        }
        else
        {
            $mensaje = array('exito' => false, 'mensaje' => 'no se ha logrado guardar el objeto');
        }
        return $response->getBody()->write($mensaje);
    }

    public function VerificarOvni($request, $response)
    {
        $body = $request->getParsedBody();
        $body = json_decode($body['json']);
        $objeto = new Alien($body->tipo, $body->velocidad, $body->planetaOrigen,$body->pathFoto);
        if (json_decode(Alien::Existe($objeto))) {
            $newResponse = $response->withJson($objeto);
        } else {
            $newResponse = $response->getBody()->write("No se pudo crear la cookie, hubo un error!");
        }
        return $newResponse;
    }

    public function listarTodos($request, $response)
    {
        $lista = json_decode(Alien::Traer());
        $newResponse = $response->withJson($lista);
        return $newResponse;
    }

    public function Agregar($request, $response)
    {
        $body = $request->getParsedBody();
        $archivo = $request->getUploadedFiles();
        $body = json_decode($body['json']);
        $rutaArchivo = DAO::moverArchivos($archivo['pathFoto'], './archivos/imagenes/', $body->tipo, $body->planetaOrigen);
        $alien = new Alien($body->tipo, $body->velocidad, $body->planetaOrigen, );
        if($alien->Agregar())
        {
            $mensaje = array('exito' => true, 'mensaje' => 'se ha guardado el objeto con exito');
        }
        else
        {
            $mensaje = array('exito' => false, 'mensaje' => 'no se ha logrado guardar el objeto');
        }
        return $response->getBody()->write($mensaje);
    }
}
