<?php

class controladorUfologo
{
    public function alta($request, $response)
    {
        $body = $request->getParsedBody();
        $ufologo = new Ufologo($body['pais'], $body['legajo'], $body['clave']);
        $mensaje = $ufologo->guardarEnArchivo();
        return $response->getBody()->write($mensaje);
    }

    public function verificar($request, $response)
    {
        $body = $request->getParsedBody();
        $objeto = new ufologo('---', $body['legajo'], $body['clave']);
        $mensaje = json_decode(ufologo::verificarExistencia($objeto));
        if ($mensaje->exito) {
            $auxiliarUfologo = json_decode($objeto->ToJSON());
            setcookie($auxiliarUfologo->legajo, date("Y-m-d H:i:s") . " -- " . $mensaje->mensaje, time() + 60 * 60 * 24, "./MostrarCookie");
            $lista = json_decode(ufologo::traerTodos());
            $newResponse = $response->withJson($lista);
        } else {
            $mensaje->mensaje = "No se pudo crear la cookie, hubo un error!";
            $newResponse = $response->withJson($mensaje);
        }
        return $newResponse;
    }

    public function listarTodos($request, $response)
    {
        $lista = json_decode(ufologo::traerTodos());
        $newResponse = $response->withJson($lista);
        return $newResponse;
    }

    public function mostrarCookie($request, $response)
    {
        $body = $request->getQueryParams();
        $json = json_decode($body['json']);
        $cookie = $request->getCookieParam($json->legajo);
        if (!is_null($cookie)) {
            $response = $response->getBody()->write($cookie);
        } else {
            $response = $response->getBody()->write('no se encuentra la cookie');
        }
        return $response;
    }
}
