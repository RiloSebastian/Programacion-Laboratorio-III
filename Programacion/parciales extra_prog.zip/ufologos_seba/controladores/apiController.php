<?php
class ApiController
{
    public $archivoPersona;

    public function __construct()
    {
        $this->archivoPersona = new DAO('./archivos/persona.json');
    }

    /**
     * lista todos los objetos de un archivo
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @return type $newResponse. array de objetos en formato json
     **/
    public function listarTodos($request, $response)
    {
        $listaObjetos = json_decode($this->archivoPersona->listar());
        $newResponse = $response->withJson($listaObjetos);
        return $newResponse;
    }

    /**
     * lista un objeto de un archivo
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @return type $newResponse. el objeto en formato json
     **/
    public function listarUno($request, $response, $args)
    {
        $id = $args['id'];
        $objeto = $this->archivoPersona->obtenerPorId('id', $id);
        $newResponse = $response->withJson($objeto);
        return $newResponse;
    }

    /**
     * carga un objeto con paramteros ya validados dentro de un array de objetos en un archivo
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @return type $newResponse. el objeto en formato json
     */
    public function cargarUno($request, $response)
    {
        $body = $request->getParsedBody();
        $archivos = $request->getUploadedFiles();
        $id = $this->archivoPersona->GenerarNuevoId();
        $fotoUno = $this->archivoPersona->moverArchivos($archivos['fotoUno'], './archivos/imagenes/', $body['email'], 1);
        $fotoDos = $this->archivoPersona->moverArchivos($archivos['fotoDos'], './archivos/imagenes/', $body['email'], 2);
        $persona = new Persona($id, $body['nombre'], $body['apellido'], (int) $body['edad'], $body['clave'], $body['sexo'], $body['email'], $fotoUno, $fotoDos);
        $this->archivoPersona->guardar($persona);
        $newResponse = $response->withJson($persona);
        return $newResponse;
    }

    /**
     * modifica parametros de un objeto dentro de un archivo
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @param Type $args. array de argumentos pasados por ruta.
     * @return type $newResponse. el objeto en formato json
     */
    public function ModificarUno($request, $response, $args)
    {
        $id = $args['id'];
        $body = $request->getParsedBody();
        $archivos = $request->getUploadedFiles();
        $this->archivoPersona->modificar('id', $id, 'nombre', $body['nombre']);
        $this->archivoPersona->modificar('id', $id, 'apellido', $body['apellido']);
        $this->archivoPersona->modificar('id', $id, 'edad', (int) $body['edad']);
        $this->archivoPersona->modificar('id', $id, 'sexo', $body['sexo']);
        $this->archivoPersona->modificar('id', $id, 'email', $body['email']);
        $fotoUno = $this->archivoPersona->obtenerValor('id', $id, 'fotoUno');
        $fotoDos = $this->archivoPersona->obtenerValor('id', $id, 'fotoDos');
        $fotoUnoNueva = $this->archivoPersona->reemplazarArchivos('./archivos/imagenes/backUpImagenes/', $fotoUno, $archivos['fotoUno'], './archivos/imagenes/', $body['email'], 1);
        $this->archivoPersona->modificar('id', $id, 'fotoUno', $fotoUnoNueva);
        $fotoDosNueva = $this->archivoPersona->reemplazarArchivos('./archivos/imagenes/backUpImagenes/', $fotoDos, $archivos['fotoDos'], './archivos/imagenes/', $body['email'], 2);
        $this->archivoPersona->modificar('id', $id, 'fotoDos', $fotoDosNueva);
        return $response->withJson($this->archivoPersona->obtenerPorId('id', $id));
    }

    /**
     * modifica parametros de un objeto dentro de un archivo
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @param Type $args. array de argumentos pasados por ruta.
     * @return type $newResponse. el objeto en formato json
     */
    public function EliminarUno($request, $response, $args)
    {
        $id = $args['id'];
        unlink($this->archivoPersona->obtenerValor('id', $id, 'fotoUno'));
        unlink($this->archivoPersona->obtenerValor('id', $id, 'fotoDos'));
        $persona = $this->archivoPersona->borrar('id', $id);
        return $response->withJson(json_decode($this->archivoPersona->listar()));
    }

    /**
     * genera un token identificando a un usuario dentro del array de objetos
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @return type $token. un string del token cifrado
     */
    public function login($request, $response)
    {
        $objeto = $request->getAttribute('objetoLogin');
        unset($objeto->clave);
        $token = Token::generarToken($objeto);
        return $response->withJson($token);
    }

    /**
     * realiza una accion recibiendo la data del usuario del token. validada antes en un middleware
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @return type $objeto. la data del usuario en formato json
     */
    public function algoDeUsuario($request, $response)
    {
        $objeto = $request->getAttribute('objetoToken');
        return $response->withJson($objeto);
    }

    /**
     * muestra una lista de todos los informes de consultas hechas en la api
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @return type $newResponse. lista de logs en formato json
     */
    public function mostrarLogs($request, $response)
    {
        $archivoLog = new DAO('./archivos/info.log');
        $listaLog = json_decode($archivoLog->listar());
        $newResponse = $response->withJson($listaLog);
        return $newResponse;
    }

    /**
     * muestra una lista filtrada de los informes de consultas hechas en la api
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @return type $newResponse. lista de logs filtrados en formato json
     */
    public function mostrarLogsFiltro($request, $response)
    {
        $archivoLog = new DAO('./archivos/info.log');
        $filtro = $request->getParsedBody();
        $filtro = $filtro['fecha'];
        $filtroLog = strtotime($filtro);
        $listaLog = json_decode($archivoLog->listar());
        $listaLogFiltrada = array();
        foreach ($listaLog as $objeto) {
            $fechaLog = strtotime($objeto->fecha);
            //condicion de filtro
            if ($fechaLog > $filtroLog) {
                array_push($listaLogFiltrada, $objeto);
            }
        }
        $newResponse = $response->withJson($listaLogFiltrada);
        return $newResponse;
    }

}
