<?php
class Ufologo
{

    const ARCHIVO = './archivos/ufologos.json';
    private $pais;
    private $legajo;
    private $clave;

    public function __construct($pais, $legajo, $clave)
    {
        $this->pais = $pais;
        $this->legajo = $legajo;
        $this->clave = $clave;
    }

    public function ToJSON()
    {
        return json_encode(array(
            'pais'=> $this->pais,
            'legajo'=> $this->legajo,
            'clave'=> $this->clave
        ));
    }

    public function guardarEnArchivo()
    {
        $mensaje;
        $objetos = array();
        if(file_exists(self::ARCHIVO)){
            $objetos = json_decode(self::traerTodos());
        }
        $archivo = fopen(self::ARCHIVO, "w");
        array_push($objetos, json_decode($this->ToJSON()));
        if (fwrite($archivo, json_encode($objetos)) !== false) {
            fclose($archivo);
            $mensaje = array('exito' => true, 'mensaje' => 'se ha guardado el objeto con exito');
        } else {
            $mensaje = array('exito' => false, 'mensaje' => 'no se ha logrado guardar el objeto');
        }
        return json_encode($mensaje);
    }

    public static function traerTodos()
    {
        if (file_exists(self::ARCHIVO)) {
            $lista = file_get_contents(self::ARCHIVO);
            return $lista;
        }
        return null;
    }

    public static function verificarExistencia($ufologo)
    {
        $array = json_decode(self::traerTodos());
        $flag = 0;
        $mensaje;
        foreach ($array as $elemento) {
            if ($elemento->clave === $ufologo->clave && $elemento->legajo === $ufologo->legajo) {
                $flag = 1;
                $mensaje = array('exito' => true, 'mensaje' => 'se ha encontrado el objeto con exito');
                break;
            }
        }
        if ($flag == 0) {
            $mensaje = array('exito' => false, 'mensaje' => 'no se ha logrado encontrar el objeto');
        }
        return json_encode($mensaje);
    }

}
