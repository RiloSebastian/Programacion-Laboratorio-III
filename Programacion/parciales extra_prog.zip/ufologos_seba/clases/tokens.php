<?php
//hay que instalar firebase con: 'composer require firebase/php-jwt'
use \Firebase\JWT\JWT;

class Token
{
    public static $cifrado = 'HS256';
    public static $claveSecreta = 'miClaveNoTanSecreta123';

    //si se le va a agregar fechas de expiracion, darles una suma elevada porque expiran rapido.
    //recordar actualizar los headers segun la contraseña y los datos que vayamos modificando.
    /**
     * genera un string del token cifrado con fecha de creacion, de expiracion e informacion en un array
     *
     * @param Type $data. un array de la informacion que se va a adherir al token
     * @return Type $token. un string del token cifrado.
     */
    public static function generarToken($data)
    {
        $ahora = time();
        $payload = array(
            'iat' => $ahora,
            'exp' => $ahora + (60 * 60 * 4),
            'data' => $data,
        );
        $token = JWT::encode($payload, self::$claveSecreta);
        return $token;
    }

    /**
     * intenta verificar y decifrar un token recibido
     *
     * @param Type $token. un string del token cifrado.
     * @return Type $decodificado. un array con todos los parametros del token
     */
    public static function verificarToken($token)
    {
        if (empty($token) || $token === "") {
            throw new Exception('el token esta vacio');
        }
        try {
            $decodificado = JWT::decode($token, self::$claveSecreta, [self::$cifrado]);
        } catch (Exception $e) {
            throw new Exception('el token no es valido. ' . $e->getMessage());
        }
        return $decodificado;
    }

    /**
     * obtiene la data de un token cifrado
     *
     * @param Type $token. un string del token cifrado.
     * @return Type $decodificado. un array de la data
     */
    public static function obtenerData($token)
    {
        $decodificado = self::verificarToken($token);
        return (array) $decodificado->data;
    }
}
