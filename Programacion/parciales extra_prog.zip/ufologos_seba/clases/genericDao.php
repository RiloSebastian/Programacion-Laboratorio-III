<?php

class DAO
{
    public $archivo;

    public function __construct($archivo)
    {
        $this->archivo = $archivo;
    }

    /**
     * guarda un objeto en un array de objetos dentro de un archivo
     *
     * @param Type $objeto el objeto a guardar
     * @return Type true si se pudo guardar con exito. false de lo contrario
     */
    public function guardar($objeto): bool
    {
        try {
            $objetos = array();
            if (file_exists($this->archivo)) {
                $objetos = json_decode($this->listar());
            }
            $archivo = fopen($this->archivo, "w");
            array_push($objetos, $objeto);
            fwrite($archivo, json_encode($objetos));
            return true;
        } catch (Exception $e) {
            throw new Exception("El objeto no se guardo", 0, $e);
        } finally {
            fclose($archivo);
        }
    }

    /**
     * lee todo el contenido de un archivo
     *
     * @return Type $lista si pudo obtener los contenidos del archivo. null de lo contrario
     */
    public function listar()
    {
        try {
            if (file_exists($this->archivo)) {
                $lista = file_get_contents($this->archivo);
                return $lista;
            } else {
                return null;
            }
        } catch (Exception $e) {
            throw new Exception("El archivo No se pudo listar", 0, $e);
        }
    }

    /**
     * borra un objeto en un array de objetos dentro de un archivo
     *
     * @param Type $nombreClave el nombre de un parametro clave unico para identificar al objeto
     * @param Type $valor valor del parametro clave que se debe buscar
     * @return Type true si se pudo borrar con exito. false de lo contrario
     */
    public function borrar($nombreClave, $valor): bool
    {
        try {
            $retorno = false;
            $objetos = json_decode($this->listar());
            $archivo = fopen($this->archivo, "w");
            foreach ($objetos as $clave => $objeto) {
                if ($objeto->$nombreClave == $valor) {
                    unset($objetos[$clave]);
                    $objetos = array_values($objetos);
                    $retorno = true;
                    break;
                }
            }
            fwrite($archivo, json_encode($objetos));
            return $retorno;
        } catch (Exception $e) {
            throw new Exception("El objeto no se borro", 0, $e);
        } finally {
            fclose($archivo);
        }
    }

    /**
     * modifica un objeto en un array de objetos dentro de un archivo
     *
     * @param Type $nombreClave el nombre de un parametro clave unico para identificar al objeto
     * @param Type $valor valor del parametro clave que se debe buscar
     * @param Type $claveModificada nombre del parametro del objeto que se va a modificar
     * @param Type $valorModificado el valor del parametro a modificar
     * @return Type true si se pudo guardar con exito. false de lo contrario
     */
    public function modificar($nombreClave, $valor, $claveModificada, $valorModificado): bool
    {
        try {
            $retorno = false;
            $objetos = json_decode($this->listar());
            if ($objetos != null) {
                $archivo = fopen($this->archivo, "w");
                foreach ($objetos as $objeto) {
                    if ($objeto->$nombreClave == $valor) {
                        $objeto->$claveModificada = $valorModificado;
                        $retorno = true;
                        break;
                    }
                }
                fwrite($archivo, json_encode($objetos));
            }
            return $retorno;
        } catch (Exception $e) {
            throw new Exception("El objeto no se pudo modificar", 0, $e);
        } finally {
            if ($objetos != null) {
                fclose($archivo);
            }
        }
    }

    /**
     * obtiene un objeto del array de objetos en un archivo por el valor de un parametro
     *
     * @param Type $idKey el nombre de un parametro clave unico para identificar al objeto
     * @param Type $idValue valor del parametro clave que se debe buscar
     * @return Type $object si se pudo borrar con exito. false de lo contrario
     */
    public function obtenerPorId($idKey, $idValue)
    {
        $objects = json_decode($this->listar());
        if ($objects != null) {
            foreach ($objects as $object) {
                if ($object->$idKey == $idValue) {
                    return $object;
                }
            }
        }
        return null;
    }

    /**
     * obtiene un array de objetos de un archivo por el valor de un parametro compartido
     *
     * @param Type $attrKey el nombre de un parametro clave unico para identificar al objeto
     * @param Type $attrValue valor del parametro clave que se debe buscar
     * @return Type $retorno array con los objetos filtrados
     */
    public function getByAttribute($attrKey, $attrValue)
    {
        try {
            $objects = json_decode($this->listar());
            $retorno = array();
            foreach ($objects as $object) {
                if ($object->$attrKey == $attrValue) {
                    array_push($retorno, $object);
                }
            }
            if (count($retorno) > 0) {
                return json_encode($retorno);
            } else {
                return null;
            }
        } catch (Exception $e) {
            throw new Exception("El archivo No se listo segun el parametro '$attrKey' ", 0, $e);
        }
    }

    /**
     * obtiene un array de objetos de un archivo por el valor de un parametro compartido caseInsensitive
     *
     * @param Type $attrKey el nombre de un parametro clave unico para identificar al objeto
     * @param Type $attrValue valor del parametro clave que se debe buscar
     * @return Type $retorno array con los objetos filtrados
     */
    public function getByAttributeCaseInsensitive($attrKey, $attrValue)
    {
        try {
            $objects = json_decode($this->listar());
            $retorno = array();
            foreach ($objects as $object) {
                if (strtolower($object->$attrKey) == strtolower($attrValue)) {
                    array_push($retorno, $object);
                }
            }
            if (count($retorno) > 0) {
                return json_encode($retorno);
            } else {
                return null;
            }
        } catch (Exception $e) {
            throw new Exception("El archivo No se listo segun el parametro '$attrKey' ", 0, $e);
        }
    }

    /**
     * obtiene un array de valores de los objetos un archivo por el valor de un parametro compartido
     *
     * @param Type $attrKey el nombre de un parametro clave unico para identificar al objeto
     * @return Type $retorno array con los objetos filtrados
     */
    public function ObtenerArrayDeValor($attrKey)
    {
        $objects = json_decode($this->listar());
        if ($objects != null) {
            $retorno = array();
            foreach ($objects as $object) {
                if (isset($object->$attrKey)) {
                    array_push($retorno, $object->$attrKey);
                } else {
                    echo 'este parametro no existe dentro del objeto';
                }
            }
            return $retorno;
        }
        return null;
    }

    /**
     * obtiene el valor de un parametro en el objeto dentro de un archivo especificado por una clave primaria
     *
     * @param Type $idKey el nombre de un parametro clave unico para identificar al objeto
     * @param Type $idValue el valor del parametro clave
     * @param Type $attrKey el nombre del parametro cuyo valor se quiere obtener
     * @return Type valor del atributo requerido
     */
    public function obtenerValor($idKey, $idValue, $attrKey)
    {
        $object = $this->obtenerPorId($idKey, $idValue);
        if (isset($object->$attrKey)) {
            return $object->$attrKey;
        }
        return null;
    }

    /**
     * genera un nuevo id para identificar un objeto a agregar al archivo
     *
     * @return Type $max valor del nuevo id
     */
    public function GenerarNuevoId()
    {
        $max = 1;
        $objects = json_decode($this->listar());
        if ($objects != null) {
            foreach ($objects as $object) {
                if ($object->id > $max) {
                    $max = $object->id;
                }
            }
            return $max + 1;
        }
        return 1;
    }

    /**
     * obtiene la cantidad de objetos guardados en un archivo
     *
     * @return Type $retorno array con los objetos filtrados
     */
    public function cantidadDeObjetosEnArchivo()
    {
        $contador = 0;
        $objects = json_decode($this->listar());
        if ($objects != null) {
            foreach ($objects as $object) {
                $contador++;
            }
            return $contador;
        }
        return 0;
    }

    /**
     * mueve un archivo a la capeta deseada
     *
     * @param Type $archivo array con informacion del archivo pasado
     * @param Type $destino ruta de la carpeta donde se busca mover el archivo
     * @param Type $identificadorPrimario valor que va a identificar la imagen
     * @param Type $identificadorSecundario valor que va a identificar en detalles mas amplios la imagen
     * @return Type nueva ruta al archivo
     */
    public static function moverArchivos($archivo, $destino, $identificadorPrimario, $identificadorSecundario)
    {
        $nombre = $archivo->getClientFileName();
        $extension = explode('.', $nombre);
        $extension = array_reverse($extension);
        $nuevaRuta = $destino . $identificadorPrimario . '_' . $identificadorSecundario . '.' . $extension[0];
        $archivo->moveTo($nuevaRuta);
        return addslashes($nuevaRuta);
    }

    /**
     * reemplaza un archivo con otro en la capeta deseada y el anterior archivo se almacena en una nueva ruta
     *
     * @param Type $destino ruta de la carpeta donde se busca mover el archivo a reemplazar
     * @param Type $archivoOriginal direccion con nombre y extension del archivo al que hay que reemplazar
     * @param Type $archivoNuevo array con informacion del archivo pasado
     * @param Type $dest ruta de la carpeta donde se busca mover el archivo nuevo
     * @param Type $idPrim valor que va a identificar la imagen
     * @param Type $idSec valor que va a identificar en detalles mas amplios la imagen
     * @return Type nueva ruta al archivo nuevo
     */
    public static function reemplazarArchivos($destino, $archivoOriginal, $archivoNuevo, $dest, $idPrim, $idSec)
    {
        $extension = explode('.', $archivoOriginal);
        $extension = array_reverse($extension);
        $fecha = date('Y-m-d-H-i');
        $rutaNuevaArchivoOriginal = $destino . $idPrim . '_' . $idSec . '_' . $fecha . '.' . $extension[0];
        rename($archivoOriginal, $rutaNuevaArchivoOriginal);
        $rutaArchivoNuevo = self::moverArchivos($archivoNuevo, $dest, $idPrim, $idSec);
        return addslashes($rutaArchivoNuevo);
    }

    /**
     * cifra un string habilitandolo para contraseña
     *
     * @param Type $password. el string a cifrar
     * @return Type $hash. el string cifrado
     */
    public static function cifrarPassword($password)
    {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        return $hash;
    }

    /**
     * compara un string con una contraseña para saber si son la misma
     *
     * @param Type $password. el string a comparar
     * @param Type $hash. el string cifrado comapardo
     * @return $password si se verifico el string. null de lo contrario
     */
    public static function decifrarPassword($password, $hash)
    {
        if (password_verify($password, $hash)) {
            return $password;
        }
        return null;
    }

    public static function es_mail($variable)
    {
        if (is_string($variable) && strpos($variable, '@') !== false) {
            return true;
        }
        return false;
    }

    public static function es_edad($variable)
    {
        if (is_numeric($variable) && (int) $variable >= 1 && (int) $variable <= 99) {
            return true;
        }
        return false;
    }

    public static function es_fecha($variable)
    {
        if (preg_match('/^(\d{4})(\/|-)(0[1-9]|1[0-2])\2([0-2][0-9]|3[0-1])(\s)([0-1][0-9]|2[0-3])(:)([0-5][0-9])$/', $variable)) {
            return true;
        }
        return false;
    }

    public static function es_alfabetico($variable)
    {
        if (preg_match('/[a-zA-Z]{2,50}/')) {
            return true;
        }
        return false;
    }

    public static function es_tel($variable)
    {
        if (preg_match('/^\(?\d{2}\)?[\s\.-]?\d{4}[\s\.-]?\d{4}$/', $variable)) {
            return true;
        }
        return false;
    }
}
