<?php

interface IParte2
{
    public function Agregar();
    public function Traer();
    public function ActivarVelocidadWarp();
    public function Existe($obj);
}
