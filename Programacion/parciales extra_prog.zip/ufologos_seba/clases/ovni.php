<?php

class Ovni implements IParte2
{

    const ARCHIVO_ALIENS = './archivos/aliens.json';

    public $tipo;
    public $velocidad;
    public $planetaOrigen;
    public $pathFoto;

    public function __construct($tipo = '--', $velocidad = '--', $planetaOrigen = '--', $pathFoto = '--')
    {
        $this->tipo = $tipo;
        $this->velocidad = $velocidad;
        $this->planetaOrigen = $planetaOrigen;
        $this->pathFoto = $pathFoto;
    }

    public function ToJson()
    {
        return json_encode(array(
            'tipo' => $this->tipo,
            'velocidad' => $this->velocidad,
            'planetaOrigen' => $this->planetaOrigen,
            'pathFoto' => $this->pathFoto,
        ));
    }

    public function Agregar()
    {
        $objetos = array();
        if(file_exists(self::ARCHIVO_ALIENS)){
            $objetos = json_decode(self::traerTodos());
        }
        $archivo = fopen(self::ARCHIVO_ALIENS, "w");
        array_push($objetos, json_decode($this->ToJSON()));
        if (fwrite($archivo, json_encode($objetos)) !== false) {
            fclose($archivo);
            return true;
        } 
        return false;
    }

    public static function Traer()
    {
        if (file_exists(self::ARCHIVO_ALIENS)) {
            $lista = file_get_contents(self::ARCHIVO_ALIENS);
            return $lista;
        }
        return null;
    }

    public function ActivarVelocidadWarp()
    {
        return $this->velocidad * 10.45;
    }

    public static function Existe($ovni)
    {
        $array = json_decode(self::traerTodos());
        $mensaje;
        foreach ($array as $elemento) {
            if ($elemento->ToJson() === $ovni->ToJson()) {
                return true;
                break;
            }
        }
        return false;
    }
}
