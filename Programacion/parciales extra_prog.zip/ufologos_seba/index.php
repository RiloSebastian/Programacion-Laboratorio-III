<?php
date_default_timezone_set('America/Argentina/Buenos_Aires');
require_once './vendor/autoload.php';
require_once './clases/genericDao.php';
require_once './clases/ufologo.php';
require_once './controladores/controladorUfologo.php';
require_once './middleware/middleware.php';



$config["displayErrorDetails"] = true; 
$config["addContentLengthHeader"] = false;
$app = new \Slim\App(["settings" => $config]);

$app->post('/AltaUfologo', \controladorUfologo::class . ':alta');

$app->post('/VerificarUfologo', \controladorUfologo::class . ':verificar');

$app->get('/ListadoUfologos', \controladorUfologo::class . ':listarTodos');

$app->get('/MostrarCookie', \controladorUfologo::class . ':mostrarCookie');

$app->run();

