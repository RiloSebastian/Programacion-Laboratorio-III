<?php

use App\Models\ORM\cd;
use App\Models\ORM\alumno;
use App\Models\ORM\profesor;
use App\Models\ORM\admin;
use App\Models\ORM\cdControler;
use Slim\App;

include_once __DIR__ . '/../../src/app/modelORM/cd.php';
include_once __DIR__ . '/../../src/app/modelORM/alumno.php';
include_once __DIR__ . '/../../src/app/modelORM/profesor.php';
include_once __DIR__ . '/../../src/app/modelORM/admin.php';
include_once __DIR__ . '/../../src/app/modelORM/cdControler.php';

return function (App $app) {
    $container = $app->getContainer();

    $app->group('/Usuarios', function () {

        $this->get('/TraerTodos',cdControler::class . ':traerTodos');

        $this->get('/TraerUno/{id}',cdControler::class . ':traerUno');

        $this->post('/Usuario',cdControler::class . ':CargarUno');

        $this->put('/ModificarUno/{id}',cdControler::class . ':ModificarUno');

        $this->delete('/EliminarUno/{id}',cdControler::class . ':BorrarUno');


    });

    $app->group('/cdORM2', function () {

        $this->get('/', cdControler::class . ':traerTodos');

    });

};
