<?php
namespace App\Models\ORM;

use App\Models\IApiControler;
use App\Models\ORM\cd;

include_once __DIR__ . '/cd.php';
include_once __DIR__ . '../../modelAPI/IApiControler.php';

class cdControler implements IApiControler
{
    public function Beinvenida($request, $response, $args)
    {
        $response->getBody()->write("GET => Bienvenido!!! ,a UTN FRA SlimFramework");

        return $response;
    }

    public function TraerTodos($request, $response, $args)
    {
        $todosLosCds = cd::all();
        $newResponse = $response->withJson($todosLosCds, 200);
        return $newResponse;
    }
    public function TraerUno($request, $response, $args)
    {
        $id = $args['id'];
        $cdElegido = cd::find($id);
        $newResponse = $response->withJson($cdElegido, 200);
        return $newResponse;
    }

    public function CargarUno($request, $response, $args)
    {
        $cd = new cd;
        $parametros = $request->getParsedBody();
        $cd->email = $parametros['email'];
        $cd->clave = $parametros['clave'];
        $cd->tipo = $parametros['tipo'];
        $cd->save();
        $cdElegido = cd::find("$cd->id");
        $newResponse = $response->withJson($cdElegido, 200);
        return $newResponse;
    }
    public function BorrarUno($request, $response, $args)
    {
        $id = $args['id'];
        $cdElegido = cd::find($id);
        $cdElegido->delete();
        $todosLosCds = cd::all();
        $newResponse = $response->withJson($todosLosCds, 200);
        return $newResponse;
    }

    public function ModificarUno($request, $response, $args)
    {
        $id = $args['id'];
        $cdElegido = cd::find($id);
        $parametros = $request->getParsedBody();
        $cdElegido->email = $parametros['email'];
        $cdElegido->clave = $parametros['clave'];
        $cdElegido->tipo = $parametros['tipo'];
        $cdElegido->save();
        $newResponse = $response->withJson($cdElegido, 200);
        return $newResponse;
    }

}
