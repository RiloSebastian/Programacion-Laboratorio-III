<?php

class Imagen
{
    public $infoArchivos;
    
    public function __construct($infoArchivos)
    {
        $this->infoArchivos= $infoArchivos;
    }

    public function moverImagen($legajo){
        if($this->infoArchivos["imagen"]["error"]==0)
        {
            $rutaArchivoUno = $this->infoArchivos["imagen"]["tmp_name"];
            $extensionArchivo= explode('/',$_FILES["imagen"]["type"]);
            $rutaArchivoFinal= "./fotos/$legajo".".$extensionArchivo[1]";
            $rtaUno= move_uploaded_file($rutaArchivoUno,"$rutaArchivoFinal");
            if($rtaUno == true){
                return $rutaArchivoFinal;
            }
        }
        return "error. no se pudo guardar el archivo";
    }

    public function modificarImagen($object){
        if($this->infoArchivos["imagen"]["error"]==0)
        {
            $fecha= strtotime(date('d-m-Y H:i:00',time()));
            $nombreArchivo= explode('/',$object->imagen);
            $nombreArchivo=array_reverse($nombreArchivo);
            var_dump($nombreArchivo);

            if(copy("$object->imagen","./fotos/backup_imagenes/"."$fecha"."-$nombreArchivo[0]"))
            {
               return $this->moverImagen($object->legajo);
            }
        }
        return "error. no se pudo modificar el archivo";
    }
}

?>