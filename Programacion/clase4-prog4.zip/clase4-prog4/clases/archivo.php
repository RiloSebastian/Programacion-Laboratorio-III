<?php

class ArchivoDao
{
    public $archivo;

    public function __construct($archivo)
    {
        $this->archivo = $archivo;
    }
    
    public function guardar($object){
        $archivo = fopen($this->archivo,"w");
        fwrite($archivo,"$object->nombre".'-'."$object->legajo".'-'."$object->imagen");
        
        fclose($archivo);
    }
    public function listar(){
        $objects = array();
        $archivo = fopen($this->archivo,"r");
        while(!feof($archivo)) {
            $aux = explode(" - ", fgets($archivo));
            if(count($aux) > 2) {
                $object = new Object($aux[0], $aux[1], $aux[2]);
                array_push($objects, $object);
            }
        }
        fclose($archivo);
        return json_encode($objects);
    }

}



?>