<?php

class Persona
{
    public $nombre;
    public $imagen;
    public $legajo;

    public function __construct($nombre, $legajo, $imagen)
    {
        $this->nombre = $nombre;
        $this->legajo = $legajo; 
        $this->imagen = $imagen;
    }

}

?>