<?php
session_start();

include_once "./clases/persona.php";
include_once "./clases/archivo.php";
include_once "./clases/imagenes.php";


var_dump($_POST);
var_dump($_FILES);
var_dump($_SESSION["persona"]);
echo "----------------------------------";
$archivo= new archivoDao("./persona.txt");

/*
if(isset($_POST["nombre"],$_POST["legajo"],$_FILES["imagen"])){
    $imagen= new imagen($_FILES);
    $persona =new persona($_POST["nombre"],$_POST["legajo"],$imagen->moverImagen($_POST["legajo"]));
    $_SESSION["persona"]=$persona;
}
*/

$_SESSION["persona"]->imagen= $imagen->modificarImagen($_SESSION["persona"]);

var_dump($_SESSION["persona"]);

/*
session_unset();
session_destroy();
*/
?>
