<?php
date_default_timezone_set('America/Argentina/Buenos_Aires');
require_once './vendor/autoload.php';
require_once './clases/genericDao.php';
require_once './clases/personas.php';
require_once './clases/tokens.php';
require_once './controladores/apiController.php';
require_once './middleware/middleware.php';

$config["displayErrorDetails"] = true;
$config["addContentLengthHeader"] = false;
$app = new \Slim\App(["settings" => $config]);

$app->group('/personas', function () {

    $this->get('/listarTodos', \ApiController::class . ':listarTodos');

    $this->get('/listarUno/{id}', \ApiController::class . ':listarUno')->add(\Middleware::class . ':validarArgs');

    $this->post('/cargarUno', \ApiController::class . ':cargarUno')->add(\Middleware::class . ':validarDatosCargar');

    $this->post('/modificarUno/{id}', \ApiController::class . ':ModificarUno')->add(\Middleware::class . ':validarDatosModificar')->add(\Middleware::class . ':validarArgs');

    $this->delete('/eliminarUno/{id}', \ApiController::class . ':EliminarUno')->add(\Middleware::class . ':validarDatosEliminar')->add(\Middleware::class . ':validarArgs');

    $this->post('/login', \ApiController::class . ':login')->add(\Middleware::class . ':validarLogin');

    $this->post('/algoDeUsuario', \ApiController::class . ':algoDeUsuario')->add(\Middleware::class . ':validarToken');

    $this->post('/mostrarMayorAFecha', \ApiController::class . ':mostrarLogsFiltro');

    $this->post('/mostrarLogs', \ApiController::class . ':mostrarLogs');

})->add(\Middleware::class . ':log');

$app->run();
