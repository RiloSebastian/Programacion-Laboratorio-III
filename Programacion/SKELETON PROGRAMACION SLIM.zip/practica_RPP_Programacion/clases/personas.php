<?php

class Persona{
    public $id;
    public $nombre;
    public $apellido;
    public $edad;
    public $clave;
    public $sexo;
    public $email;
    public $fotoUno;
    public $fotoDos;

    public function __construct($id,$nombre,$apellido,$edad,$clave,$sexo,$email,$fotoUno,$fotoDos){
        $this->id = $id;
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->edad = $edad;
        $this->clave = $clave;
        $this->sexo = $sexo;
        $this->email = $email;
        $this->fotoUno = $fotoUno;
        $this->fotoDos = $fotoDos;
    }

}