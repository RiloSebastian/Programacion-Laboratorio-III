<?php

class Middleware
{
    public $archivoPersona;

    public function __construct()
    {
        $this->archivoPersona = new DAO('./archivos/persona.json');
    }

    /**
     * valida que los argumentos pasados en ruta sean validos
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @param Type $next. parametro de slim para ir a al metodo principal de la consulta
     * @return type $response. retorna $next o mensaje de error de lo contrario
     */
    public function validarArgs($request, $response, $next)
    {
        $id = $request->getAttribute('route')->getArgument('id');
        if (isset($id) && !empty($id)) {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('el parametro estan mal');
        }
        return $response;
    }

    /**
     * valida que los parametros pasados para cargar un nuevo objeto sean validos y que no exista otro objeto con la misma clave primaria
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @param Type $next. parametro de slim para ir a al metodo principal de la consulta
     * @return type $response. retorna $next o mensaje de error de lo contrario
     */
    public function validarDatosCargar($request, $response, $next)
    {
        $body = $request->getParsedBody();
        $archivo = $request->getUploadedFiles();
        //validar con isset todos los elementos a cargar
        if (isset($body['nombre'], $body['apellido'], $body['edad'], $body['sexo'], $body['email'], $body['clave'], $archivo['fotoUno'], $archivo['fotoDos'])) {
            //valida que en el archivo no exista otro objeto con la misma clave primaria
            if (is_null($this->archivoPersona->obtenerPorId('email', $body['email']))) {
                $response->getBody()->write('esta seteado, no es null y es unico');
                $response = $next($request, $response);
            } else {
                $response->getBody()->write('no se puede cargar. ya existe');
            }
        } else {
            $response->getBody()->write('faltan parametros');
        }
        return $response;
    }

    /**
     * valida que los parametros pasados para modificar un nuevo objeto sean validos y que exista el objeto con la misma clave primaria
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @param Type $next. parametro de slim para ir a al metodo principal de la consulta
     * @return type $response. retorna $next o mensaje de error de lo contrario
     */
    public function validarDatosModificar($request, $response, $next)
    {
        $body = $request->getParsedBody();
        $archivo = $request->getUploadedFiles();
        $id = $request->getAttribute('route')->getArgument('id');
        //validar con isset todos los elementos a modificar
        if (isset($body['nombre'], $body['apellido'], $body['edad'], $body['sexo'], $body['email'], $archivo['fotoUno'], $archivo['fotoDos'])) {
            //valida que el objeto exista en el archivo
            if (!is_null($this->archivoPersona->obtenerPorId('id', $id))) {
                $response->getBody()->write('esta seteado, no es null y existe');
                $response = $next($request, $response);
            } else {
                $response->getBody()->write('no se puede modificar. no existe');
            }
        } else {
            $response->getBody()->write('faltan parametros');
        }
        return $response;
    }

    /**
     * valida exista el objeto a eliminar con la misma clave primaria
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @param Type $next. parametro de slim para ir a al metodo principal de la consulta
     * @return type $response. retorna $next o mensaje de error de lo contrario
     */
    public function validarDatosEliminar($request, $response, $next)
    {
        $id = $request->getAttribute('route')->getArgument('id');
        if (!is_null($this->archivoPersona->obtenerPorId('id', $id))) {
            $response->getBody()->write('existe en el archivo');
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('no se puede eliminar. no existe');
        }
        return $response;
    }

    /**
     * valida que se haya pasado un token valido y que su informacion corresponda a un objeto aun activo en un archivo
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @param Type $next. parametro de slim para ir a al metodo principal de la consulta
     * @return type $response. retorna $next o mensaje de error de lo contrario
     */
    public function validarToken($request, $response, $next)
    {
        $token = $request->getHeader('token');
        if (!empty($token[0])) {
            $objeto = Token::obtenerData($token[0]);
            if (!is_null($this->archivoPersona->obtenerPorId('email', $objeto['email']))) {
                $request = $request->withAttribute('objetoToken', $objeto);
                $response = $next($request, $response);
            } else {
                $response->getBody()->write('el usuario ya no esxiste');
            }
        } else {
            $response->getBody()->write('el token no existe');
        }
        return $response;
    }

    /**
     * valida que los parametros pasados para crear un nuevo token sean validos y que exista un objeto con los parametros pasados
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @param Type $next. parametro de slim para ir a al metodo principal de la consulta
     * @return type $response. retorna $next o mensaje de error de lo contrario
     */
    public function validarLogin($request, $response, $next)
    {
        $body = $request->getParsedBody();
        if (isset($body['clave'], $body['email'])) {
            $objeto = $this->archivoPersona->obtenerPorId('email', $body['email']);
            if (!is_null($objeto)) {
                if ($objeto->clave === $body['clave']) {
                    $request = $request->withAttribute('objetoLogin', $objeto);
                    $response = $next($request, $response);
                } else {
                    $response->getBody()->write('la clave no es correcto');
                }
            } else {
                $response->getBody()->write('el objeto con este email no existe');
            }
        } else {
            $response->getBody()->write('no se encuentran parametros');
        }
        return $response;
    }

    /**
     * guarda un informe con detalles de la consulta hecha en un archivo
     *
     * @param Type $request. parametro de slim con toda la informacion recibida de la consulta
     * @param Type $response. parametro de slim para devolver informacion al servidor
     * @param Type $next. parametro de slim para ir a al metodo principal de la consulta
     * @return type $response. retorna $next o mensaje de error de lo contrario
     */
    public function log($request, $response, $next)
    {
        $archivoLog = new DAO('./archivos/info.log');
        $token = $request->getHeader('token');
        if (!empty($token[0])) {
            $usuario = Token::obtenerData($token[0])['email'];
        } else {
            $usuario = 'usuario no logeado';
        }
        $log = array(
            'fecha' => date('Y-m-d H:i'),
            'metodo' => $request->getMethod(),
            'path' => $request->getUri()->getPath(),
            'ip' => $request->getServerParam('REMOTE_ADDR'),
            'usuario' => $usuario,
        );
        $archivoLog->guardar($log);
        $response = $next($request, $response);
        return $response;
    }
}
