<?php

use App\Models\ORM\cd;
use App\Models\ORM\cdApi;
use Slim\App;

include_once __DIR__ . '/../../src/app/modelORM/cd.php';
include_once __DIR__ . '/../../src/app/modelORM/cdControler.php';

return function (App $app) {
    $container = $app->getContainer();

    $app->group('/cdORM', function () {

        $this->get('/TraerTodos', function ($request, $response, $args) {
            //return cd::all()->toJson();
            $todosLosCds = cd::all();
            $newResponse = $response->withJson($todosLosCds, 200);
            return $newResponse;
        });
        $this->get('/TraerUno/{id}', function ($request, $response, $args) {
            $id = $args['id'];
            $cdElegido = cd::find($id);
            $newResponse = $response->withJson($cdElegido, 200);
            return $newResponse;
        });
        $this->post('/AgregarUno', function ($request, $response, $args) {
            $cd = new cd;
            $parametros = $request->getParsedBody();
            $cd->titel = $parametros['titel'];
            $cd->interpret = $parametros['interpret'];
            $cd->jahr = $parametros['jahr'];
            $cd->save();
            $cdElegido = cd::find("$cd->id");
            $newResponse = $response->withJson($cdElegido, 200);
            return $newResponse;
        });
        $this->post('/ModificarUno/{id}', function ($request, $response, $args) {
            $id = $args['id'];
            $cdElegido = cd::find($id);
            $parametros = $request->getParsedBody();
            $cdElegido->titel = $parametros['titel'];
            $cdElegido->interpret = $parametros['interpret'];
            $cdElegido->jahr = $parametros['jahr'];
            $cdElegido->save();
            $newResponse = $response->withJson($cdElegido, 200);
            return $newResponse;
        });
        $this->delete('/EliminarUno/{id}', function ($request, $response, $args) {
            $id = $args['id'];
            $cdElegido = cd::find($id);
            $cdElegido->delete();
            $todosLosCds = cd::all();
            $newResponse = $response->withJson($todosLosCds, 200);
            return $newResponse;
        });
    });

    $app->group('/cdORM2', function () {

        $this->get('/', cdApi::class . ':traerTodos');

    });

};
