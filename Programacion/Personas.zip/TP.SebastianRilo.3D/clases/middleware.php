<?php

class Middleware{

    public function esAdmin($request,$response,$next)
    {
        $arrayParametros= $request->getQueryParams();
    }

    public function tieneId($request,$response,$next)
    {
        $paramsRuta= $request->getAttribute('routeInfo')[2];
            if(isset($paramsRuta['id']) && (int)$paramsRuta['id']>= 1)
            {
                echo PHP_EOL.'entro perro';
                $response= $next($request,$response);
            }
            else
            {
                echo PHP_EOL.'no entro man';
            }
        return $response;
    }
}


?>