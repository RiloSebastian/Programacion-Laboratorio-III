<?php
require_once 'apiInterface.php';

class ApiPersona  implements IApiUsable{
    public $dao;
    public function __construct()
    {
        $this->dao = new DAO('./MOCK_DATA.json');
    }
    
    public function TraerTodos($request,$response){
        return $response->withJson(json_decode($this->dao->listar()));
    }
    public function TraerUno($request,$response,$args){
        $id =$args['id'];
        return $response->withJson($this->dao->obtenerPorId('id',$id));
    }
    public function AgregarUno($request,$response){
        $array = $request->getParsedBody();
        $nuevoId = $this->dao->generarNuevoId();
        $this->dao->guardar(new Persona($nuevoId,$array['nombre'],$array['edad'],$array['email']));
        return  $response->withJson($this->dao->obtenerPorId('id',$nuevoId));
    }
    public function ModificarUno($request,$response,$args){
        $id =$args['id'];
        $valoresModificados = $request->getQueryParams();
        $this->dao->modificar('id',$id,'nombre',$valoresModificados['nombre']);
        $this->dao->modificar('id',$id,'edad',$valoresModificados['edad']);
        $this->dao->modificar('id',$id,'email',$valoresModificados['email']);
        return $response->withJson($this->dao->obtenerPorId('id',$id));
    }
    public function EliminarUno($request,$response,$args){
        $id =$args['id'];
        $persona = $this->dao->borrar('id',$id);
        return $response->withJson(json_decode($this->dao->listar()));
    }
}

?>