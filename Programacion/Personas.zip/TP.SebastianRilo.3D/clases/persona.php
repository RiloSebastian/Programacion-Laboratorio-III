<?php

class Persona{
    public $id;
    public $nombre;
    public $edad;
    public $email;

    public function __construct($id,$nombre,$edad,$email){
        $this->id = $id;
        $this->nombre = $nombre;
        $this->edad = $edad;
        $this->email = $email;
    }
}