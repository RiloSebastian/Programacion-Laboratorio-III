<?php

Interface IApiUsable{
    public function TraerTodos($request,$response);
    public function TraerUno($request,$response,$args);
    public function AgregarUno($request,$response);
    public function ModificarUno($request,$response,$args);
    public function EliminarUno($request,$response,$args);
}

?>