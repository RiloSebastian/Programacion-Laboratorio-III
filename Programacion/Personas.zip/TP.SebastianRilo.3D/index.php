<?php

require_once './vendor/autoload.php';
require_once './clases/Api.php';
require_once './clases/genericDao.php';
require_once './clases/persona.php';
require_once './clases/middleware.php';

$config["displayErrorDetails"]=true;
$config["addContentLengthHeader"]=false;
$app = new \Slim\App(["settings"=> $config]);

$app->group('/miPagina',function(){

    $this->get("/TraerTodos",\ApiPersona::class . ':TraerTodos')->add(\Middleware::class . ':esAdmin');

    $this->get("/TraerUno/{id}", \ApiPersona::class . ':TraerUno')->add(\Middleware::class . ':tieneId');

    $this->post("/AgregarUno", \ApiPersona::class . ':AgregarUno');

    $this->delete("/EliminarUno/{id}", \ApiPersona::class . ':EliminarUno');
    
    $this->put("/ModificarUno/{id}", \ApiPersona::class . ':ModificarUno');
});
$app->run();