-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 17-12-2019 a las 21:33:01
-- Versión del servidor: 10.4.8-MariaDB
-- Versión de PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tpcomanda`
--
CREATE DATABASE IF NOT EXISTS `tpcomanda` DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish2_ci;
USE `tpcomanda`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargo_empleados`
--

CREATE TABLE `cargo_empleados` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `cargo_empleados`
--

INSERT INTO `cargo_empleados` (`id`, `nombre`, `Created_at`, `Updated_at`) VALUES
(1, 'Socio', '2019-12-13 18:07:52', '2019-12-13 18:09:15'),
(2, 'Mozo', '2019-12-13 18:07:52', '2019-12-13 18:09:21'),
(3, 'Cocinero', '2019-12-13 18:07:52', '2019-12-13 18:09:27'),
(4, 'Bartender', '2019-12-13 18:07:52', '2019-12-13 18:09:33'),
(5, 'Cervecero', '2019-12-13 18:07:52', '2019-12-13 18:09:38');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `apellido` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `cargo` int(11) NOT NULL,
  `clave` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`id`, `nombre`, `apellido`, `email`, `cargo`, `clave`, `estado`, `Created_at`, `Updated_at`) VALUES
(1, 'sebastian', 'rilo', 'sebastianrilo@email.com', 1, 'paseSocio', 1, '2019-12-13 15:38:08', '2019-12-15 13:36:00'),
(2, 'octavio', 'villegas', 'octavioVillegas@email.com', 1, 'paseSocio', 1, '2019-12-13 15:38:08', '2019-12-15 13:36:13'),
(3, 'mario', 'rampi', 'mariorampi@email.com', 1, 'paseSocio', 1, '2019-12-13 15:38:08', '2019-12-15 13:36:28'),
(4, 'numero1', 'empleado', 'empleado1@email.com', 2, 'paseEmpleado', 1, '2019-12-13 15:43:07', '2019-12-15 13:36:43'),
(5, 'numero2', 'empleado', 'empleado2@email.com', 2, 'paseEmpleado', 1, '2019-12-13 15:45:36', '2019-12-15 13:36:52'),
(7, 'numero3', 'empleado', 'empleado3@email.com', 3, 'paseEmpleado', 1, '2019-12-17 02:22:10', '2019-12-17 02:22:10'),
(8, 'numero4', 'empleado', 'empleado4@email.com', 4, 'paseEmpleado', 1, '2019-12-17 02:22:31', '2019-12-17 02:22:31'),
(9, 'numero5', 'empleado', 'empleado5@email.com', 5, 'paseEmpleado', 1, '2019-12-17 02:22:41', '2019-12-17 02:22:41');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_mesas`
--

CREATE TABLE `estado_mesas` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `estado_mesas`
--

INSERT INTO `estado_mesas` (`id`, `nombre`, `Created_at`, `Updated_at`) VALUES
(1, 'con cliente esperando pedido', '2019-12-13 18:14:11', '2019-12-13 18:14:11'),
(2, 'con cliente comiendo', '2019-12-13 18:14:11', '2019-12-13 18:14:11'),
(3, 'con cliente pagando', '2019-12-13 18:14:11', '2019-12-13 18:14:11'),
(4, 'cerrada', '2019-12-13 18:14:11', '2019-12-13 18:14:11');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_pedidos`
--

CREATE TABLE `estado_pedidos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `estado_pedidos`
--

INSERT INTO `estado_pedidos` (`id`, `nombre`, `Created_at`, `Updated_at`) VALUES
(1, 'en espera', '2019-12-13 18:24:07', '2019-12-13 18:24:07'),
(2, 'en preparacion', '2019-12-13 18:24:07', '2019-12-13 18:24:07'),
(3, 'listo para servir', '2019-12-13 18:24:07', '2019-12-13 18:24:07'),
(4, 'servido', '2019-12-13 18:24:07', '2019-12-13 18:24:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `usuario` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `metodo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `accion` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `sector` int(11) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `logs`
--

INSERT INTO `logs` (`id`, `usuario`, `metodo`, `accion`, `sector`, `Created_at`, `Updated_at`) VALUES
(1, 'sebastianrilo@email.com', 'GET', 'Comanda/Empleados/TraerTodos', 1, '2019-12-18 00:03:22', '2019-12-18 00:03:22'),
(2, 'sebastianrilo@email.com', 'POST', 'Comanda/PuntuarServicio/1tIYZ', 1, '2019-12-18 00:07:47', '2019-12-18 00:07:47'),
(3, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeIngresoEmpleados', 1, '2019-12-18 00:13:00', '2019-12-18 00:13:00'),
(4, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeIngresoEmpleados', 1, '2019-12-18 00:13:27', '2019-12-18 00:13:27'),
(5, 'sebastianrilo@email.com', 'POST', 'Comanda/InformePorSector/1', 1, '2019-12-18 00:14:23', '2019-12-18 00:14:23'),
(6, 'sebastianrilo@email.com', 'POST', 'Comanda/InformePorSector/2', 1, '2019-12-18 00:14:41', '2019-12-18 00:14:41'),
(7, 'sebastianrilo@email.com', 'POST', 'Comanda/InformePorEmpleado/1', 1, '2019-12-18 00:15:11', '2019-12-18 00:15:11'),
(8, 'sebastianrilo@email.com', 'POST', 'Comanda/InformePorEmpleado/4', 1, '2019-12-18 00:15:15', '2019-12-18 00:15:15'),
(9, 'sebastianrilo@email.com', 'POST', 'Comanda/InformePorEmpleado/sebastianrilo@email.com', 1, '2019-12-18 00:15:29', '2019-12-18 00:15:29'),
(10, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:16:02', '2019-12-18 00:16:02'),
(11, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:17:36', '2019-12-18 00:17:36'),
(12, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:18:58', '2019-12-18 00:18:58'),
(13, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:19:32', '2019-12-18 00:19:32'),
(14, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:20:18', '2019-12-18 00:20:18'),
(15, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:20:54', '2019-12-18 00:20:54'),
(16, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:21:12', '2019-12-18 00:21:12'),
(17, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:21:51', '2019-12-18 00:21:51'),
(18, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:22:50', '2019-12-18 00:22:50'),
(19, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:23:39', '2019-12-18 00:23:39'),
(20, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:24:00', '2019-12-18 00:24:00'),
(21, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:24:18', '2019-12-18 00:24:18'),
(22, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:24:49', '2019-12-18 00:24:49'),
(23, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:25:24', '2019-12-18 00:25:24'),
(24, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:26:00', '2019-12-18 00:26:00'),
(25, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:26:21', '2019-12-18 00:26:21'),
(26, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMasVendido', 1, '2019-12-18 00:28:29', '2019-12-18 00:28:29'),
(27, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMenosVendido', 1, '2019-12-18 00:28:37', '2019-12-18 00:28:37'),
(28, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMenosVendido', 1, '2019-12-18 00:29:08', '2019-12-18 00:29:08'),
(29, 'sebastianrilo@email.com', 'POST', 'Comanda/InformeProductoMenosVendido', 1, '2019-12-18 00:30:30', '2019-12-18 00:30:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mesas`
--

CREATE TABLE `mesas` (
  `id` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  `codigo` varchar(5) COLLATE utf8_spanish2_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `mesas`
--

INSERT INTO `mesas` (`id`, `id_empleado`, `codigo`, `estado`, `Created_at`, `Updated_at`) VALUES
(1, 4, 'MSA01', 4, '2019-12-13 18:24:07', '2019-12-17 02:16:12'),
(2, 4, 'MSA02', 4, '2019-12-13 18:24:07', '2019-12-17 02:54:02'),
(3, 4, 'MSA03', 4, '2019-12-13 18:24:07', '2019-12-13 18:24:07'),
(4, 5, 'MSA04', 4, '2019-12-13 18:24:07', '2019-12-13 17:14:38'),
(5, 5, 'MSA05', 4, '2019-12-13 18:24:07', '2019-12-13 17:15:16'),
(6, 5, 'MSA06', 4, '2019-12-13 18:24:07', '2019-12-13 17:15:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `nombreCliente` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `codigoPedido` varchar(5) COLLATE utf8_spanish2_ci NOT NULL,
  `codigoMesa` varchar(5) COLLATE utf8_spanish2_ci NOT NULL,
  `precio` int(11) NOT NULL,
  `tiempo` timestamp NOT NULL DEFAULT current_timestamp(),
  `imagen` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id`, `nombreCliente`, `codigoPedido`, `codigoMesa`, `precio`, `tiempo`, `imagen`, `estado`, `Created_at`, `Updated_at`) VALUES
(21, 'Enrique', '1tIYZ', 'MSA01', 485, '2019-12-17 01:17:24', '', 4, '2019-12-17 01:16:47', '2019-12-17 02:00:35'),
(22, 'Teresa', 'kku9Y', 'MSA02', 680, '2019-12-17 02:41:53', '', 4, '2019-12-17 02:40:53', '2019-12-17 02:50:13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido_productos`
--

CREATE TABLE `pedido_productos` (
  `codigo` varchar(5) COLLATE utf8_spanish2_ci NOT NULL,
  `id_producto` int(11) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `pedido_productos`
--

INSERT INTO `pedido_productos` (`codigo`, `id_producto`, `Created_at`, `Updated_at`) VALUES
('1tIYZ', 5, '2019-12-17 01:16:47', '2019-12-17 01:16:47'),
('1tIYZ', 7, '2019-12-17 01:16:47', '2019-12-17 01:16:47'),
('1tIYZ', 9, '2019-12-17 01:16:47', '2019-12-17 01:16:47'),
('1tIYZ', 2, '2019-12-17 01:16:47', '2019-12-17 01:16:47'),
('1tIYZ', 10, '2019-12-17 01:16:47', '2019-12-17 01:16:47'),
('1tIYZ', 20, '2019-12-17 01:16:47', '2019-12-17 01:16:47'),
('kku9Y', 3, '2019-12-17 02:40:53', '2019-12-17 02:40:53'),
('kku9Y', 18, '2019-12-17 02:40:53', '2019-12-17 02:40:53'),
('kku9Y', 25, '2019-12-17 02:40:53', '2019-12-17 02:40:53'),
('kku9Y', 1, '2019-12-17 02:40:54', '2019-12-17 02:40:54'),
('kku9Y', 4, '2019-12-17 02:40:54', '2019-12-17 02:40:54'),
('kku9Y', 6, '2019-12-17 02:40:54', '2019-12-17 02:40:54'),
('kku9Y', 16, '2019-12-17 02:40:54', '2019-12-17 02:40:54'),
('kku9Y', 8, '2019-12-17 02:40:54', '2019-12-17 02:40:54'),
('kku9Y', 12, '2019-12-17 02:40:54', '2019-12-17 02:40:54');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `precio` int(11) NOT NULL,
  `tiempo` int(11) NOT NULL,
  `id_cargo` int(11) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `precio`, `tiempo`, `id_cargo`, `Created_at`, `Updated_at`) VALUES
(1, 'pepsi', 30, 5, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(2, 'sevenUp', 35, 5, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(3, 'mirinda', 40, 5, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(4, 'paso de los toros', 40, 5, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(5, 'h2O', 35, 5, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(6, 'pepsi light', 45, 5, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(7, 'schneider', 60, 7, 5, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(8, 'corona', 80, 7, 5, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(9, 'heineken', 75, 7, 5, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(10, 'stella artois', 95, 7, 5, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(11, 'empanadas', 95, 10, 3, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(12, 'pizza muzarella', 160, 10, 3, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(13, 'hamburguesa con queso', 150, 10, 3, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(14, 'milanesas', 180, 10, 3, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(15, 'ensalada rusa', 120, 10, 3, '2019-12-13 18:42:10', '2019-12-13 18:45:35'),
(16, 'vino blanco', 105, 6, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(17, 'vino tinto', 95, 6, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(18, 'vino rosa', 100, 6, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(19, 'tequila', 160, 6, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(20, 'whiskey', 185, 6, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(21, 'champagne', 190, 6, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(22, 'vodka', 200, 6, 4, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(23, 'torta de ricota', 120, 10, 3, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(24, 'pastel de membrillo', 75, 10, 3, '2019-12-13 18:42:10', '2019-12-13 18:42:10'),
(25, 'alfazores de maizena', 80, 10, 3, '2019-12-13 18:42:10', '2019-12-13 18:42:10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntuacions`
--

CREATE TABLE `puntuacions` (
  `id` int(11) NOT NULL,
  `pedido` varchar(5) COLLATE utf8_spanish2_ci NOT NULL,
  `puntuacion_mesa` int(11) NOT NULL,
  `puntuacion_restaurante` int(11) NOT NULL,
  `puntuacion_mozo` int(11) NOT NULL,
  `puntuacion_cocinero` int(11) NOT NULL,
  `resenia` varchar(66) COLLATE utf8_spanish2_ci NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `puntuacions`
--

INSERT INTO `puntuacions` (`id`, `pedido`, `puntuacion_mesa`, `puntuacion_restaurante`, `puntuacion_mozo`, `puntuacion_cocinero`, `resenia`, `Created_at`, `Updated_at`) VALUES
(1, '1tIYZ', 5, 7, 4, 6, 'muy regular el servicio. me parecio bien', '2019-12-18 00:07:47', '2019-12-18 00:07:47');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifas`
--

CREATE TABLE `tarifas` (
  `codigo_pedido` varchar(5) COLLATE utf8_spanish2_ci NOT NULL,
  `codigo_mesa` varchar(5) COLLATE utf8_spanish2_ci NOT NULL,
  `costo` int(11) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `tarifas`
--

INSERT INTO `tarifas` (`codigo_pedido`, `codigo_mesa`, `costo`, `Created_at`, `Updated_at`) VALUES
('1tIYZ', 'MSA01', 485, '2019-12-17 02:09:34', '2019-12-17 02:09:34'),
('kku9Y', 'MSA02', 680, '2019-12-17 02:50:29', '2019-12-17 02:50:29');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cargo_empleados`
--
ALTER TABLE `cargo_empleados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cargo` (`cargo`);

--
-- Indices de la tabla `estado_mesas`
--
ALTER TABLE `estado_mesas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado_pedidos`
--
ALTER TABLE `estado_pedidos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mesas`
--
ALTER TABLE `mesas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD UNIQUE KEY `codigo_2` (`codigo`),
  ADD KEY `estado` (`estado`),
  ADD KEY `id_empleado` (`id_empleado`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigoPedido` (`codigoPedido`),
  ADD KEY `codigoMesa` (`codigoMesa`),
  ADD KEY `estado` (`estado`);

--
-- Indices de la tabla `pedido_productos`
--
ALTER TABLE `pedido_productos`
  ADD KEY `codigo` (`codigo`),
  ADD KEY `id_producto` (`id_producto`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_cargo` (`id_cargo`);

--
-- Indices de la tabla `puntuacions`
--
ALTER TABLE `puntuacions`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tarifas`
--
ALTER TABLE `tarifas`
  ADD PRIMARY KEY (`codigo_pedido`),
  ADD KEY `codigo_mesa` (`codigo_mesa`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cargo_empleados`
--
ALTER TABLE `cargo_empleados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `estado_mesas`
--
ALTER TABLE `estado_mesas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `estado_pedidos`
--
ALTER TABLE `estado_pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `mesas`
--
ALTER TABLE `mesas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `puntuacions`
--
ALTER TABLE `puntuacions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD CONSTRAINT `empleados_ibfk_1` FOREIGN KEY (`cargo`) REFERENCES `cargo_empleados` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `mesas`
--
ALTER TABLE `mesas`
  ADD CONSTRAINT `mesas_ibfk_1` FOREIGN KEY (`estado`) REFERENCES `estado_mesas` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `mesas_ibfk_2` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`estado`) REFERENCES `estado_pedidos` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `pedidos_ibfk_4` FOREIGN KEY (`codigoMesa`) REFERENCES `mesas` (`codigo`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `pedido_productos`
--
ALTER TABLE `pedido_productos`
  ADD CONSTRAINT `pedido_productos_ibfk_1` FOREIGN KEY (`codigo`) REFERENCES `pedidos` (`codigoPedido`) ON UPDATE CASCADE,
  ADD CONSTRAINT `pedido_productos_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `tarifas`
--
ALTER TABLE `tarifas`
  ADD CONSTRAINT `tarifas_ibfk_1` FOREIGN KEY (`codigo_pedido`) REFERENCES `pedidos` (`codigoPedido`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tarifas_ibfk_2` FOREIGN KEY (`codigo_mesa`) REFERENCES `mesas` (`codigo`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
