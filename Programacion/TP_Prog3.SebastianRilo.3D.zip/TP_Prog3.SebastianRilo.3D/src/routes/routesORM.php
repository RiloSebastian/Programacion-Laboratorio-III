<?php

use App\Models\ORM\EmpleadoController;
use App\Models\ORM\MesaController;
use App\Models\ORM\MiddlewareComanda;
use App\Models\ORM\PedidoController;
use App\Models\ORM\ProductoController;
use App\Models\ORM\TarifaController;
use App\Models\ORM\InformeController;
use Slim\App;

include_once __DIR__ . '/../../src/app/modelORM/controladores/empleadoController.php';
include_once __DIR__ . '/../../src/app/modelORM/middleware/middlewareComanda.php';
include_once __DIR__ . '/../../src/app/modelORM/controladores/mesaController.php';
include_once __DIR__ . '/../../src/app/modelORM/controladores/pedidoController.php';
include_once __DIR__ . '/../../src/app/modelORM/controladores/productoController.php';
include_once __DIR__ . '/../../src/app/modelORM/controladores/tarifaController.php';
include_once __DIR__ . '/../../src/app/modelORM/controladores/informeController.php';

return function (App $app) {
    $container = $app->getContainer();

    $app->group('/Comanda', function () {

        $this->post('/Login', EmpleadoController::class . ':logIn'); //token para realizar acciones especificas de empleado o cliente

        $this->get('/MostrarLogin', EmpleadoController::class . ':mostrarLogIn')
            ->add(MiddlewareComanda::class . ':validarToken'); //muestra usuario logueado

        $this->group('/Empleados', function () { //solo socios

            $this->get('/TraerTodos', EmpleadoController::class . ':TraerTodos');

            $this->get('/TraerUno/{id}', EmpleadoController::class . ':TraerUno');

            $this->post('/CargarUno', EmpleadoController::class . ':CargarUno');

            $this->post('/ModificarUno/{id}', EmpleadoController::class . ':ModificarUno');

            $this->delete('/EliminarUno/{id}', EmpleadoController::class . ':BorrarUno');

            $this->post('/SuspenderUno/{id}', \empleadoControler::class . ':suspenderUno');

        })->add(MiddlewareComanda::class . ':esSocio')
            ->add(MiddlewareComanda::class . ':validarToken');;

        $this->group('/Pedidos', function () { //solo socios y mozos

            $this->get('/TraerTodos', PedidoController::class . ':TraerTodos')
                ->add(MiddlewareComanda::class . ':esSocio')
                ->add(MiddlewareComanda::class . ':validarToken');

            $this->get('/TraerUno/{id}', PedidoController::class . ':TraerUno')
                ->add(MiddlewareComanda::class . ':esSocio')
                ->add(MiddlewareComanda::class . ':validarToken');

            $this->post('/CargarUno/{codigoMesa}', PedidoController::class . ':CargarUno')
                ->add(MiddlewareComanda::class . ':esMozo')
                ->add(MiddlewareComanda::class . ':validarToken');

            $this->post('/ModificarUno/{id}', PedidoController::class . ':ModificarUno')
                ->add(MiddlewareComanda::class . ':esSocio')
                ->add(MiddlewareComanda::class . ':validarToken');

            $this->delete('/EliminarUno/{id}', PedidoController::class . ':BorrarUno')
                ->add(MiddlewareComanda::class . ':esSocio')
                ->add(MiddlewareComanda::class . ':validarToken');

        });

        $this->group('/Productos', function () { //solo socios

            $this->get('/TraerTodos', ProductoController::class . ':TraerTodos');

            $this->get('/TraerUno/{id}', ProductoController::class . ':TraerUno');

            $this->post('/CargarUno', ProductoController::class . ':CargarUno');

            $this->post('/ModificarUno/{id}', ProductoController::class . ':ModificarUno');

            $this->delete('/EliminarUno/{id}', ProductoController::class . ':BorrarUno');
        })->add(MiddlewareComanda::class . ':esSocio')
            ->add(MiddlewareComanda::class . ':validarToken');

        $this->group('/Mesas', function () { //solo socios
            $this->get('/TraerTodos', MesaController::class . ':TraerTodos')
                ->add(MiddlewareComanda::class . ':esSocio')
                ->add(MiddlewareComanda::class . ':validarToken');

            $this->get('/TraerUno/{id}', MesaController::class . ':TraerUno')
                ->add(MiddlewareComanda::class . ':esSocio')
                ->add(MiddlewareComanda::class . ':validarToken');

            $this->post('/CargarUno', MesaController::class . ':CargarUno')
                ->add(MiddlewareComanda::class . ':esSocio')
                ->add(MiddlewareComanda::class . ':validarToken');

            $this->post('/ModificarUno/{id}', MesaController::class . ':ModificarUno')
                ->add(MiddlewareComanda::class . ':esSocio')
                ->add(MiddlewareComanda::class . ':validarToken');

            $this->delete('/EliminarUno/{id}', MesaController::class . ':BorrarUno')
                ->add(MiddlewareComanda::class . ':esSocio')
                ->add(MiddlewareComanda::class . ':validarToken');
        });

        $this->post('/AcomodarClientes', MesaController::class . ':acomodarCliente')
            ->add(MiddlewareComanda::class . ':esMozo')
            ->add(MiddlewareComanda::class . ':validarToken'); // solo mozo

        $this->post('/TomarPedido/{codigoMesa}', PedidoController::class . ':CargarUno'); //solo mozo

        $this->post('/PrepararPedido/{codigoPedido}', PedidoController::class . ':prepararPedido')
            ->add(MiddlewareComanda::class . ':esMozo')
            ->add(MiddlewareComanda::class . ':validarToken'); //solo mozo

        $this->post('/TerminarPedido/{codigoPedido}', PedidoController::class . ':terminarPedido')
            ->add(MiddlewareComanda::class . ':esSocio')
            ->add(MiddlewareComanda::class . ':validarToken'); //solo empleado

        $this->post('/ServirPedido/{codigoPedido}', PedidoController::class . ':servirPedido')
            ->add(MiddlewareComanda::class . ':esMozo')
            ->add(MiddlewareComanda::class . ':validarToken'); //solo mozo

        $this->post('/CobrarPedido/{codigoPedido}', PedidoController::class . ':cobrarPedido')
            ->add(MiddlewareComanda::class . ':esSocio')
            ->add(MiddlewareComanda::class . ':validarToken'); //solo socio

        $this->get('/MostrarTarifa/{codigoPedido}', TarifaController::class . ':mostrarTarifa');

        $this->post('/CerrarMesa/{codigoMesa}', MesaController::class . ':cerrarMesa'); //solo socio

        $this->get('/MostrarListaPedidosPendientes', PedidoController::class . ':verPedidosPendientes'); //empleado no socio ni mozo logueado

        $this->post('/PuntuarServicio/{codigoPedido}', InformeController::class . ':puntuarServicio');
        
        $this->post('/InformeIngresoEmpleados', InformeController::class . ':informeIngresoEmpleados');

        $this->post('/InformePorSector/{sector}', InformeController::class . ':InformePorSector');

        $this->post('/InformePorEmpleado/{usuario}', InformeController::class . ':InformePorEmpleado');

        $this->post('/InformeProductoMasVendido', InformeController::class . ':informeProductoMasVendido');

        $this->post('/InformeProductoMenosVendido', InformeController::class . ':informeProductoMenosVendido');

        $this->post('/InformeMesaMasUsada', InformeController::class . ':informeMesaMasUsada');

        $this->post('/InformeMesaMenosUsada', InformeController::class . ':informeMesaMenosUsada');

        $this->post('/InformeMesaMasFacturada', InformeController::class . ':informeMesaMasFacturada');

        $this->post('/InformeMesaMenosFacturada', InformeController::class . ':informeMesaMenosFacturada');

        $this->post('/InformeMesaMaximoPrecio', InformeController::class . ':informeMesaMaximoPrecio');

        $this->post('/InformeMesaMinimoPrecio', InformeController::class . ':informeMesaMinimoPrecio');

    })->add(InformeController::class . ':guardarOperacionesLog');
};
