<?php
namespace App\Models\ORM;

use App\Models\AutentificadorJWT;
use App\Models\ORM\empleado;
use App\Models\ORM\mesa;
use App\Models\ORM\pedido;

include_once __DIR__ . './../clases/empleado.php';
include_once __DIR__ . './../../modelAPI/AutentificadorJWT.php';

class MiddlewareComanda
{
    public function validarToken($request, $response, $next)
    {
        $token = $request->getHeader('token');
        if (!empty($token)) {
            $datos = AutentificadorJWT::obtenerData($token[0]);
            if (!empty($datos) && empleado::find($datos['id']) != null) {
                $response = $next($request, $response);
            } else {
                $response->getBody()->write('no se encuentra el usuario');
            }
        } else {
            $response->getBody()->write('no se paso un token');
        }
        return $response;
    }

    public function esSocio($request, $response, $next)
    {
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        if ($datos['cargo'] === 1) {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('no es socio');
        }
        return $response;
    }

    public function esMozo($request, $response, $next)
    {
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        if ($datos['cargo'] === 2) {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('no es mozo');
        }
        return $response;
    }

    public function esEmpleado($request, $response, $next)
    {
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        if ($datos['cargo'] > 2) {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('no es mozo');
        }
        return $response;
    }

    public function validarArgId($request, $response, $next)
    {
        $id = $request->getAttribute('route')->getArgument('id');
        if (isset($id) && !empty($id)) {
            if (empleado::find((int) $id) !== null) {
                $response = $next($request, $response);
            } else {
                $response->getBody()->write('el id no existe');
            }
        } else {
            $response->getBody()->write('el parametro estan mal');
        }
        return $response;
    }
    public function validarArgCodigoPedido($request, $response, $next)
    {
        $id = $request->getAttribute('route')->getArgument('codigoPedido');
        if (isset($id) && !empty($id)) {
            if (pedido::where('codigoPedido', $id)->exists() !== false) {
                $response = $next($request, $response);
            } else {
                $response->getBody()->write('el codigo del pedido no existe');
            }
        } else {
            $response->getBody()->write('el parametro estan mal');
        }
        return $response;
    }
    public function validarArgCodigoMesa($request, $response, $next)
    {
        $id = $request->getAttribute('route')->getArgument('CodigoMesa');
        if (isset($id) && !empty($id)) {
            if (mesa::where('codigo', $id)->exists() !== false) {
                $response = $next($request, $response);
            } else {
                $response->getBody()->write('el codigo de mesa no existe');
            }
        } else {
            $response->getBody()->write('el parametro estan mal');
        }
        return $response;
    }

    public function validarCargarEmpleado($request, $response, $next)
    {
        $body = $request->getParsedBody();
        if (isset($body['nombre'], $body['apellido'], $body['email'], $body['cargo'], $body['clave'])) {
            if (empleado::where('email', $body['email'])->exists() === false) {
                $response = $next($request, $response);
            } else {
                $response->getBody()->write('no se puede cargar. ya existe');
            }
        } else {
            $response->getBody()->write('faltan parametros');
        }
        return $response;
    }
    public function validarCargarMesa($request, $response, $next)
    {
        $body = $request->getParsedBody();
        if (isset($body['id_empleado'])) {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('faltan parametros');
        }
        return $response;
    }

    public function validarCargarPedido($request, $response, $next)
    {
        $body = $request->getParsedBody();
        $archivo = $request->getUploadedFiles();
        if (isset($body['nombreCliente'], $body['codigoMesa'], $body['productos'], $archivo['imagen'])) {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('faltan parametros');
        }
        return $response;
    }

    public function validarMesaCerrada($request, $response, $next){
        $id = $request->getAttribute('route')->getArgument('CodigoMesa');
        $mesa = mesa::where('codigo',$id)->first();
        if($mesa->estado === 4 ){
            $response = $next($request,$response);
        }
        else{
            $response->getBody()->write('la mesa no esta cerrada');
        }
        return $response;
    }


}
