<?php
namespace App\Models\ORM;

use App\Models\AutentificadorJWT;
use App\Models\ORM\empleado;

include_once __DIR__ . './../clases/empleado.php';

class EmpleadoController
{
    public function TraerTodos($request, $response, $args)
    {
        $empleados = empleado::where("cargo", "!=", 1)->get();
        if (count($empleados) > 0) {
            return $response->withJson($empleados, 200);
        }
        return $response->withJson("No hay empleados cargados", 200);
    }

    public function TraerUno($request, $response, $args)
    {
        $id = $args['id'];
        $empleadoElegido = empleado::find($id);
        $newResponse = $response->withJson($empleadoElegido, 200);
        return $newResponse;
    }

    public function CargarUno($request, $response, $args)
    {
        $empleado = new empleado;
        $body = $request->getParsedBody();
        $empleado->nombre = $body['nombre'];
        $empleado->apellido = $body['apellido'];
        $empleado->email = $body['email'];
        $empleado->cargo = (int) $body['cargo'];
        $empleado->clave = $body['clave'];
        $empleado->save();
        $empleadoElegido = empleado::find($empleado->id);
        $newResponse = $response->withJson($empleadoElegido, 200);
        return $newResponse;
    }

    public function BorrarUno($request, $response, $args)
    {
        $id = $args['id'];
        $empleadoElegido = empleado::find((int) $id);
        $empleadoElegido->delete();
        $todosLosempleados = empleado::all();
        $newResponse = $response->withJson($todosLosempleados, 200);
        return $newResponse;
    }

    public function ModificarUno($request, $response, $args)
    {
        $id = $args['id'];
        $empleado = empleado::find((int) $id);
        $body = $request->getParsedBody();
        if (isset($body['nombre'])) {
            $empleado->nombre = $body['nombre'];
        }
        if (isset($body['apellido'])) {
            $empleado->apellido = $body['apellido'];
        }
        if (isset($body['email'])) {
            $empleado->email = $body['email'];
        }
        if (isset($body['cargo'])) {
            $empleado->cargo = (int) $body['cargo'];
        }
        if (isset($body['clave'])) {
            $empleado->clave = $body['clave'];
        }
        if (isset($body['estado'])) {
            $empleado->estado = $body['estado'];
        }
        $empleado->save();
        $newResponse = $response->withJson($empleado, 200);
        return $newResponse;
    }

    public function logIn($request, $response)
    {
        $parametros = $request->getParsedBody();
        $elemento = empleado::where('clave', $parametros['clave'])->where('email', $parametros['email'])->first();
        $datos = array(
            'id' => $elemento->id,
            'nombre' => $elemento->nombre,
            'apellido' => $elemento->apellido,
            'email' => $elemento->email,
            'cargo' => $elemento->cargo
        );
        $jwt = AutentificadorJWT::CrearToken($datos);
        $newResponse = $response->withJson($jwt);
        if (empty($newResponse)) {
            $newResponse = $response->getBody()->write('no existe un usuario con estos parametros');
        }
        return $newResponse;
    }

    public function mostrarLogIn($request, $response)
    {
        $data = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        return $response->withJson($data);
    }

}
