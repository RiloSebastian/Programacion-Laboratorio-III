<?php
namespace App\Models\ORM;

use App\Models\AutentificadorJWT;
use App\Models\ORM\producto;
include_once __DIR__ . './../clases/producto.php';


class ProductoController
{
    public function TraerTodos($request, $response, $args)
    {
        $todosLosProductos = producto::all();
        $newResponse = $response->withJson($todosLosProductos, 200);
        return $newResponse;
    }

    public function TraerUno($request, $response, $args)
    {
        $id = $args['id'];
        $productoElegido = producto::find($id);
        $newResponse = $response->withJson($productoElegido, 200);
        return $newResponse;
    }

    public function CargarUno($request, $response, $args)
    {
        $producto = new producto;
        $body = $request->getParsedBody();
        $producto->nombre = $body['nombre'];
        $producto->precio = (int)$body['precio'];
        $producto->tiempo = (int)$body['tiempo'];
        $producto->id_cargo = (int)$body['id_cargo'];
        $producto->save();
        $productoElegido = producto::find($producto->id);
        $newResponse = $response->withJson($productoElegido, 200);
        return $newResponse;
    }

    public function BorrarUno($request, $response, $args)
    {
        $id = $args['id'];
        $productoElegido = producto::find($id);
        $productoElegido->delete();
        $todosLosproductos = producto::all();
        $newResponse = $response->withJson($todosLosproductos, 200);
        return $newResponse;
    }

    public function ModificarUno($request, $response, $args)
    {
        $id = $args['id'];
        $producto = producto::find($id);
        $body = $request->getParsedBody();
        if (isset($body['nombre'])) {
            $producto->nombre = $body['nombre'];
        }
        if (isset($body['precio'])) {
            $producto->precio = (int)$body['precio'];
        }
        if (isset($body['tiempo'])) {
            $producto->tiempo = (int)$body['tiempo'];
        }
        if (isset($body['id_cargo'])) {
            $producto->id_cargo = (int)$body['id_cargo'];
        }
        $producto->save();
        $newResponse = $response->withJson($producto, 200);
        return $newResponse;
    }

}
