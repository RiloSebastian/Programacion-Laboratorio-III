<?php
namespace App\Models\ORM;

use App\Models\ORM\log;
use App\Models\ORM\puntuacion;
use App\Models\ORM\empleado;
use App\Models\ORM\pedido;
use App\Models\ORM\producto;
use App\Models\ORM\pedido_producto;
use App\Models\AutentificadorJWT;

include_once __DIR__ . './../clases/log.php';
include_once __DIR__ . './../clases/puntuacion.php';
include_once __DIR__ . './../clases/empleado.php';
include_once __DIR__ . './../clases/pedido_producto.php';
include_once __DIR__ . './../clases/pedido.php';
include_once __DIR__ . './../../modelAPI/AutentificadorJWT.php';

class InformeController
{

    public function guardarOperacionesLog($request, $response, $next)
    {
        $token = $request->getHeader('token');
        if (!empty($token[0])) {
            $usuario = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
            $sector =  $usuario['cargo'];
            $usuario = $usuario['email'];
            $log = new log;
            $log->usuario = $usuario;
            $log->metodo = $request->getMethod();
            $log->accion = $request->getUri()->getPath();
            $log->sector = $sector;
            $log->save();
        }
        $response = $next($request, $response);
        return $response;
    }

    public function puntuarServicio($request, $response, $args)
    {
        $codigoPedido = $args['codigoPedido'];
        $body = $request->getParsedBody();
        $puntuacion = new puntuacion;
        $puntuacion->pedido = $codigoPedido;
        $puntuacion->puntuacion_mesa = (int)$body['mesa'];
        $puntuacion->puntuacion_restaurante = (int)$body['restaurante'];
        $puntuacion->puntuacion_mozo = (int)$body['mozo'];
        $puntuacion->puntuacion_cocinero = (int)$body['cocinero'];
        $puntuacion->resenia = $body['resenia'];
        $puntuacion->save();
        return $response->withJson($puntuacion);
    }

    public function informeIngresoEmpleados($request, $response)
    {
        $body = $request->getParsedBody();
        $fechaMin = strtotime($body['fechaMinima']);
        if (isset($body['fechaMaxima'])) {
            $fechaMax = strtotime($body['fechaMaxima']);
            $empleados = empleado::where('Created_at', '>=', $fechaMin)->where('Created_at', '<=', $fechaMax)->get();
        } else {
            $empleados = empleado::where('Created_at', '>=', $fechaMin)->get();
        }
        return $response->withJson($empleados);
    }

    public function informePorSector($request, $response, $args)
    {
        $sector = $args['sector'];
        $logs = log::where('sector', $sector)->get();
        return $response->withJson($logs);
    }

    public function InformePorEmpleado($request, $response, $args)
    {
        $usuario = $args['usuario'];
        $logs = log::where('usuario', $usuario)->get();
        return $response->withJson($logs);
    }

    public function informeProductoMasVendido($request, $response)
    {
        $idMasComprado = pedido_producto::select('id_producto')->groupBy('id_producto')->orderByRaw('COUNT(*) DESC')->first();
        $producto = producto::find($idMasComprado->id_producto);
        $nombre = $producto->nombre;
        return $response->getBody()->write('el producto mas comprado fue ' . $nombre);
    }

    public function informeProductoMenosVendido($request, $response)
    {
        $idMenosComprado = pedido_producto::select('id_producto')->groupBy('id_producto')->orderByRaw('COUNT(*) ASC')->first();    
        $producto = producto::find($idMenosComprado->id_producto);
        return $response->getBody()->write('el producto menos comprado fue ' . $producto->nombre);
    }

    public function informeMesaMasUsada($request, $response)
    {
        $codigoMasUsada = pedido::select('codigoMesa')->groupBy('codigoMesa')->orderByRaw('COUNT(*) DESC')->first();
        return $response->getBody()->write('la mesa mas usada fue ' . $codigoMasUsada->codigoMesa);
    }

    public function informeMesaMenosUsada($request, $response)
    {
        $codigoMenosUsada = pedido::select('codigoMesa')->groupBy('codigoMesa')->orderByRaw('COUNT(*) ASC')->first();    
        return $response->getBody()->write('la mesa menos usada fue ' . $codigoMenosUsada->codigoMesa);
    }

    public function informeMesaMasFacturada($request, $response){
        $masTarifada = tarifa::selectRaw('codigo_mesa,SUM(precio) as precio_total FROM tarifas GROUP by codigo_mesa ORDER by precio_total DESC LIMIT 1');
        return $response->getBody()->write('la mesa mas facturada fue '.$masTarifada);
    }

    public function informeMesaMenosFacturada($request, $response){
        $menosTarifada = tarifa::selectRaw('codigo_mesa,SUM(precio) as precio_total FROM tarifas GROUP by codigo_mesa ORDER by precio_total ASC LIMIT 1');
        return $response->getBody()->write('la mesa menos facturada fue '.$menosTarifada);
    }

    public function informeMesaMaximoPrecio($request, $response){
        $maximoPrecio = tarifa::select('codigo_mesa')->max('precio');
        return $response->getBody()->write('la mesa con mayor precio fue '.$maximoPrecio);
    }

    public function informeMesaMinimoPrecio($request, $response){
        $minimoPrecio = tarifa::select('codigo_mesa')->min('precio');
        return $response->getBody()->write('la mesa con menor precio fue '.$minimoPrecio);
    }

}
