<?php
namespace App\Models\ORM;

use App\Models\AutentificadorJWT;
use App\Models\ORM\mesa;
use App\Models\ORM\pedido;
use App\Models\ORM\pedido_producto;
use App\Models\ORM\Pedido_ProductoController;
use App\Models\ORM\producto;
use App\Models\ORM\TarifaController;

include_once __DIR__ . './../clases/pedido_producto.php';
include_once __DIR__ . './../clases/pedido.php';
include_once __DIR__ . './../clases/mesa.php';
include_once __DIR__ . './../clases/producto.php';
include_once __DIR__ . './pedidoProductoController.php';
include_once __DIR__ . './tarifaController.php';

class PedidoController
{
    public function TraerTodos($request, $response, $args)
    {
        $todosLosPedidos = pedido::all();
        $newResponse = $response->withJson($todosLosPedidos, 200);
        return $newResponse;
    }

    public function TraerUno($request, $response, $args)
    {
        $id = $args['id'];
        $pedidoElegido = pedido::find($id);
        $newResponse = $response->withJson($pedidoElegido, 200);
        return $newResponse;
    }

    public function CargarUno($request, $response, $args)
    {
        $codigoMesa = $args['codigoMesa'];
        $pedido = new pedido;
        $body = $request->getParsedBody();
        $archivo = $request->getUploadedFiles();
        $pedido->nombreCliente = $body['nombreCliente'];
        $pedido->codigoPedido = $this->generarCodigoPedido();
        $pedido->codigoMesa = $codigoMesa;
        $id_productos = explode(',', $body['productos']);

        if (isset($archivo['imagen'])) {
            $nombreArchivo = $this->moverArchivo($archivo['imagen'], './imagenes/pedido/', $codigoMesa, $pedido->codigoPedido);
            $pedido->imagen = $nombreArchivo;
        }
        $pedido->estado = 1;
        $pedido->save();
        foreach ($id_productos as $id) {
            if (producto::find((int) $id) !== null && (pedido_producto::where('codigo', $pedido->codigoPedido)->where('id_producto', (int) $id)->exists() === false)) {
                $rel = new pedido_producto;
                $rel->codigo = $pedido->codigoPedido;
                $rel->id_producto = (int) $id;
                $rel->save();
            }
        }
        $pedido->tiempo = date('Y-m-d H:i:s', time() + pedido_productoController::calcularTiempo($pedido->codigoPedido));
        $pedido->precio = pedido_productoController::calcularPrecio($pedido->codigoPedido);
        $pedido->save();
        $pedidoElegido = pedido::find($pedido->id);
        $newResponse = $response->withJson($pedidoElegido, 200);
        return $newResponse;
    }

    public function BorrarUno($request, $response, $args)
    {
        $id = $args['id'];
        $pedidoElegido = pedido::find($id);
        pedido_producto::where('codigo', $pedidoElegido->codigoPedido)->delete();
        if (!empty($pedidoElegido->imagen)) {
            unlink($pedidoElegido->imagen);
        }
        $pedidoElegido->delete();
        $todosLospedidos = pedido::all();
        $newResponse = $response->withJson($todosLospedidos, 200);
        return $newResponse;
    }

    public function ModificarUno($request, $response, $args)
    {
        $id = $args['id'];
        $pedido = pedido::find($id);
        $body = $request->getParsedBody();
        $archivo = $request->getUploadedFiles();
        if (isset($body['nombreCliente'])) {
            $pedido->nombreCliente = $body['nombreCliente'];
        }
        if (isset($body['codigoPedido'])) {
            pedido_producto::where('codigo', $pedido->codigoPedido)->delete();
            $pedido->codigoPedido = $body['codigoPedido'];
        }
        if (isset($body['estado'])) {
            $pedido->nombreCliente = (int) $body['estado'];
        }
        if (isset($archivo['imagen'])) {
            $nombreArchivo = $this->moverArchivo($archivo['imagen'], './imagenes/pedido/', $pedido->codigoMesa, $body['codigoPedido']);
            $pedido->imagen = $nombreArchivo;
        }
        $pedido->save();
        if (isset($body['productos'])) {
            $id_productos = explode(',', $body['productos']);
            pedido_producto::where('codigo', $pedido->codigoPedido)->delete();
            foreach ($id_productos as $id) {
                if (producto::find((int) $id) !== null && (pedido_producto::where('codigo', $pedido->codigoPedido)->where('id_producto', (int) $id)->exists() === false)) {
                    $rel = new pedido_producto;
                    $rel->codigo = $pedido->codigoPedido;
                    $rel->id_producto = (int) $id;
                    $rel->save();
                }
            }
            $pedido->tiempo = date('Y-m-d H:i:s', time() + pedido_productoController::calcularTiempo($pedido->codigoPedido));
            $pedido->precio = pedido_productoController::calcularPrecio($pedido->codigoPedido);
            $pedido->save();
        }
        $newResponse = $response->withJson($pedido, 200);
        return $newResponse;
    }

    public function generarCodigoPedido()
    {
        $codigo = null;
        do {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            for ($i = 0; $i < 5; $i++) {
                $codigo .= $characters[rand(0, $charactersLength - 1)];
            }
        } while (pedido::where('codigoPedido', $codigo) === null);
        return $codigo;
    }

    public function moverArchivo($archivo, $destino, $identificadorPrimario, $identificadorSecundario)
    {
        $nombre = $archivo->getClientFileName();
        $extension = explode('.', $nombre);
        $extension = array_reverse($extension);
        $nuevaRuta = $destino . $identificadorPrimario . '_' . $identificadorSecundario . '.' . $extension[0];
        $archivo->moveTo($nuevaRuta);
        return $nuevaRuta;
    }

    public function reemplazarArchivo($destino, $archivoOriginal, $archivoNuevo, $dest, $idPrim, $idSec)
    {
        $extension = explode('.', $archivoOriginal);
        $extension = array_reverse($extension);
        $fecha = date('Y-m-d-H-i');
        $rutaNuevaArchivoOriginal = $destino . $idPrim . '_' . $idSec . '_' . $fecha . '.' . $extension[0];
        rename($archivoOriginal, $rutaNuevaArchivoOriginal);
        $rutaArchivoNuevo = $this->moverArchivos($archivoNuevo, $dest, $idPrim, $idSec);
        return $rutaArchivoNuevo;
    }

    public function prepararPedido($request, $response, $args)
    {
        $codigo = $args['codigoPedido'];
        $pedido = pedido::where('codigoPedido', $codigo)->update(array('estado' => 2));
        $pedido = pedido::where('codigoPedido', $codigo)->first();
        return $response->getBody()->write('se comenzo a preparar el pedido ' . $pedido->codigoPedido);
    }

    public function terminarPedido($request, $response, $args)
    {
        $codigo = $args['codigoPedido'];
        $pedido = pedido::where('codigoPedido', $codigo)->update(array('estado' => 3));
        $pedido = pedido::where('codigoPedido', $codigo)->first();
        return $response->getBody()->write('se termino de preparar el pedido ' . $pedido->codigoPedido);
    }

    public function servirPedido($request, $response, $args)
    {
        $codigo = $args['codigoPedido'];
        pedido::where('codigoPedido', $codigo)->update(array('estado' => 4));
        $pedido = pedido::where('codigoPedido', $codigo)->first();
        $mesa = mesa::where('codigo', $pedido->codigoMesa)->update(array('estado' => 2));
        return $response->getBody()->write('se sirvio el pedido ' . $pedido->codigoPedido);
    }

    public function cobrarPedido($request, $response, $args)
    {
        $codigo = $args['codigoPedido'];
        $pedido = pedido::where('codigoPedido', $codigo)->first();
        $tarifa = TarifaController::CargarUno($pedido);
        $mesa = mesa::where('codigo', $pedido->codigoMesa)->update(array('estado' => 3));
        return $response->withJson($tarifa);
    }

    public function verPedidosPendientes($request, $response)
    {
        $data = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        $listaPendientes = array();
        $pedidos = pedido::where('estado', 2)->get();
        foreach ($pedidos as $pedido) {
            $productoId = pedido_producto::where('codigo', $pedido->codigoPedido)->pluck('id_producto')->toArray();
            foreach ($productoId as $id) {
                $producto = producto::find($id);
                if ($producto->id_cargo === $data['cargo']) {
                    array_push($listaPendientes, $pedido);
                    break;
                }
            }
        }
        return $response->withJson($listaPendientes);
    }
}
