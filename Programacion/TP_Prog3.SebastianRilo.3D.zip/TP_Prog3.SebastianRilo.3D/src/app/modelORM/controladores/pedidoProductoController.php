<?php
namespace App\Models\ORM;

use App\Models\ORM\pedido_producto;

include_once __DIR__ . './../clases/pedido_producto.php';

class Pedido_productoController
{
    public function calcularTiempo($codigo){
        $id_productos = pedido_producto::where('codigo',$codigo)->pluck('id_producto')->toArray();
        $total = producto::whereIn('id',$id_productos)->sum('tiempo');
        return $total;
    }

    public function calcularPrecio($codigo){
        $id_productos = pedido_producto::where('codigo',$codigo)->pluck('id_producto')->toArray();
        $total = producto::whereIn('id',$id_productos)->sum('precio');
        return $total;
    }

}
