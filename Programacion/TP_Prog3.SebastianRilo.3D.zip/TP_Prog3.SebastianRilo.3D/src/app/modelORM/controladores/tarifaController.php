<?php
namespace App\Models\ORM;

use App\Models\ORM\tarifa;

include_once __DIR__ . './../clases/tarifa.php';

class TarifaController
{
    public function CargarUno($pedido)
    {
        $tarifa = new tarifa;
        $tarifa->codigo_pedido = $pedido->codigoPedido;
        $tarifa->codigo_mesa = $pedido->codigoMesa;
        $tarifa->costo = (int) $pedido->precio;
        $tarifa->save();
        $tarifaElegido = tarifa::where('codigo_pedido', $pedido->codigoPedido)->first();
        $newResponse = $tarifaElegido;
        return $newResponse;
    }

    public function mostrarTarifa($request, $response, $args)
    {
        $codigo = $args['codigoPedido'];
        $tarifa = tarifa::where('codigo_pedido', $codigo)->get();
        return $response->withJson($tarifa);
    }

}
