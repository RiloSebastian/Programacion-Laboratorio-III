<?php
namespace App\Models\ORM;

use App\Models\ORM\mesa;

include_once __DIR__ . './../clases/mesa.php';

class MesaController
{
    public function TraerTodos($request, $response, $args)
    {
        $todasLasMesas = mesa::all();
        $newResponse = $response->withJson($todasLasMesas, 200);
        return $newResponse;
    }

    public function TraerUno($request, $response, $args)
    {
        $id = $args['id'];
        $mesaElegido = mesa::find($id);
        $newResponse = $response->withJson($mesaElegido, 200);
        return $newResponse;
    }

    public function CargarUno($request, $response, $args)
    {
        $mesa = new mesa;
        $body = $request->getParsedBody();
        $mesa->id_empleado = $body['id_empleado'];
        $mesa->codigo = $this->generarCodigoMesa();
        $mesa->estado = 4;
        $mesa->save();
        $mesaElegido = mesa::find($mesa->id);
        $newResponse = $response->withJson($mesaElegido, 200);
        return $newResponse;
    }

    public function BorrarUno($request, $response, $args)
    {
        $id = $args['id'];
        $mesaElegido = mesa::find($id);
        $mesaElegido->delete();
        $todosLosmesas = mesa::all();
        $newResponse = $response->withJson($todosLosmesas, 200);
        return $newResponse;
    }

    public function ModificarUno($request, $response, $args)
    {
        $id = $args['id'];
        $mesa = mesa::find($id);
        $body = $request->getParsedBody();
        if (isset($body['id_empleado'])) {
            $mesa->id_empleado = $body['id_empleado'];
        }
        if (isset($body['codigo'])) {
            $mesa->codigo = $body['codigo'];
        }
        if (isset($body['estado'])) {
            $mesa->estado = (int) $body['estado'];
        }
        $mesa->save();
        $newResponse = $response->withJson($mesa, 200);
        return $newResponse;
    }

    public function acomodarCliente($request, $response)
    {
        $mesa = $this->buscarMesaLibre();
        return $response->withJson($mesa, 200);
    }

    public function buscarMesaLibre()
    {
        $mesa = mesa::where('estado', 4)->first();
        $mesa->estado = 1;
        $mesa->save();
        return $mesa;
    }

    public function cerrarMesa($request, $response, $args)
    {
        $codigoMesa = $args['codigoMesa'];
        $mesa = mesa::where('codigo', $codigoMesa)->first();
        $mesa->estado = 4;
        $mesa->save();
        return $response->getBody()->write('se cerro la mesa ' . $codigoMesa);
    }

    public function generarCodigoMesa()
    {
        $codigo = null;
        do {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            for ($i = 0; $i < 5; $i++) {
                $codigo .= $characters[rand(0, $charactersLength - 1)];
            }
        } while (mesa::where('codigo', $codigo) === null);
        return $codigo;
    }

}
