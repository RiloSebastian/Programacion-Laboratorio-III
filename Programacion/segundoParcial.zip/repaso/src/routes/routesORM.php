<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\cdControler;

include_once __DIR__ . '/../../src/app/modelORM/controlador/cdControler.php';
include_once __DIR__ . '/../../src/app/modelORM/middleware/middleware.php';

return function (App $app) {
    $container = $app->getContainer();

     $app->group('/Usuario', function () {   
         
        $this->get('/mostrarTodos', cdControler::class . ':traerTodos');

        $this->get('/traerUno/{id}', cdControler::class . ':traerUno');        
        
        $this->post('/users', cdControler::class . ':cargarUser')->add( Middleware::class . ':validarDatosCargaruser');      

        $this->post('/login', cdControler::class . ':logIn');
        
        $this->put('/ingresos', cdControler::class . ':ingreso');//->add( Middleware::class . ':validarToken');;

        $this->put('/egresos', cdControler::class . ':egreso')->add( Middleware::class . ':validarToken');;
        
        

    })->add(Middleware::class . ':logs');
};