<?php


use App\Models\ORM\user;
use App\Models\AutentificadorJWT;

include_once __DIR__ . './../clases/user.php';
include_once __DIR__ . './../clases/genericDao.php';
include_once __DIR__ . './../../modelAPI/AutentificadorJWT.php';

class Middleware
{
    public function validarToken($request, $response, $next)
    {
        $response = $next($request, $response);
        // $token = $request->getHeader('token');
        // if (!empty($token)) {
        //     $datos =AutentificadorJWT::obtenerData($token[0]);
        //     if (!empty($datos) && user::find($datos['legajo']) != null) {
        //         $response = $next($request, $response);
        //     } else {
        //         $response->getBody()->write('no se encuentra el usuario');
        //     }
        // } else {
        //     $response->getBody()->write('no se paso un token');
        // }
        return $response;
    }

    public function esAdmin($request, $response, $next)
    {
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        if ($datos['tipo'] === 'admin') {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('no es admin');
        }
        return $response;
    }

    public function validarDatosCargaruser($request,$response,$next){
        $parametros = $request->getParsedBody();
        $archivos = $request->getUploadedFiles();
        if(isset($parametros['legajo']) && isset($parametros['nombre']) && isset($parametros['email']) &&
         isset($parametros['clave']) && isset($archivos['fotoUno']) && isset($archivos['fotoDos'])){
            if( (int)$parametros['legajo'] >= 1 && (int)$parametros['legajo'] < 1000 ){
                $buscar = user::find((int)$parametros['legajo']);
                if($buscar->id != $parametros['legajo']){
                    $response = $next($request,$response);
                }
            }
         }
         return $response;
    }

    public function logs($request, $response, $next)
    {
        $fecha = date('Y-m-d H:i:s');
        $token =$request->getHeader('token');
        $ip = $request->getServerParam('REMOTE_ADDR');
        $metodo = $request->getMethod();
        $ruta = $request->getUri()->getPath();
        if(!isset($token))
        {
            $usuario = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
            $nombreUsuario = $usuario['nombre'];
        }
        else
        {
            $nombreUsuario = 'no hay usuario logeado';
        }
        $log = 'FECHA: '.$fecha.' - '.'IP: '.$ip.' - '.'Metodo: '.$metodo.' - '.'RUTA: '.$ruta.' - '.'Usuario: '.$nombreUsuario;
        $dao = new Dao("./info.log");
        $dao->guardar($log);
        $response = $next($request, $response);
        return $response;
    }
}
