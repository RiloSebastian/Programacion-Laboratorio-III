<?php
namespace App\Models\ORM;

use App\Models\ORM\user;
use App\Models\ORM\materia;
use App\Models\AutentificadorJWT;

include_once __DIR__ . './../clases/user.php';
include_once __DIR__ . './../clases/genericDao.php';
include_once __DIR__ . './../../modelAPI/AutentificadorJWT.php';

class cdControler
{
    public function traerTodos($request, $response, $args)
    {
        $newResponse = user::all();
        return $response->withJson($newResponse);
    }

    public function traerUno($request, $response, $args)
    {
        $id = $args['id'];
        $newResponse = usuario::find(id);
        return $response->withJson($newResponse);
    }

    //genera un token con algunos datos de la entidad especificados en un array
    public function logIn($request, $response)
    {
        $parametros = $request->getParsedBody();
        $codificado= base64_encode($parametros['clave']);
        $coleccion = user::where('clave',$codificado)->get();
        foreach ($coleccion as $elemento) {
            if (strtolower($elemento->nombre) === strtolower($parametros['nombre']) &&
                strtolower($elemento->email) === strtolower($parametros['email'])) {
                $datos = array('legajo' => "$elemento->id", 'nombre' => "$elemento->nombre", 'email' => "$elemento->email", 'fotoUno' => "$elemento->fotoUno", 'fotodos' => "$elemento->fotoDos");
                $jwt = AutentificadorJWT::CrearToken($datos);
                $newResponse = $response->withJson($jwt);
                break;
            }
        }
        if (empty($newResponse)) {
            $newResponse = $response->getBody()->write('no existe un usuario con estos parametros');
        }
        return $newResponse;
    }


    public function cargarUser($request,$response){
        $parametros = $request->getParsedBody();
        $archivos = $request->getUploadedFiles();      
        $user = new user;
        $user->id = (int)$parametros['legajo'];
        $user->nombre = $parametros['nombre'];
        $user->email = $parametros['email'];
        $user->clave = base64_encode($parametros['clave']);
        $user->ingreso = false;
        $rutaImagen = \Dao::moverArchivos($archivos['fotoUno'],'./imagenes/user/',$parametros['email'],1);
        $user->fotoUno = $rutaImagen;
        $rutaImagen = \Dao::moverArchivos($archivos['fotoDos'],'./imagenes/user/',$parametros['email'],2);
        $user->fotoDos = $rutaImagen;
        $user->save();

        $mostrar = user::find((int)$parametros['legajo']);
        unset($mostrar->clave);
        $newResponse = $response->withJson($mostrar);
        return $newResponse;
    }

    public function ingreso($request,$response){
        $datos =AutentificadorJWT::obtenerData($token[0]);
        $ingresado = user::find((int)$datos['legajo']);
        if(!$ingresado->ingreso){
            $ingresado->ingreso = true;
        }
        else
        {
            $newResponse = $response->getBody()->write('el usuario ya esta ingresado');
        }
        
        $ingreso->horaIngreso = time();
        $ingreso->save();
    }

    public function egreso($request,$response){
        $datos =AutentificadorJWT::obtenerData($token[0]);
        $ingresado = user::find((int)$datos['legajo']);
        if($ingresado->ingreso){
            $ingresado->ingreso = true;
        }
        else
        {
            $newResponse = $response->getBody()->write('el usuario no esta ingresado');
        }
    }








    /*
    * guarda un archivo en el campo blob de una tabla en la base de datos
    * $archivo: un elemento obtenido de $_FILES para guardar (ej. $_FILES['imagen'])
    * $campoTabla: el campo tipo blob de la tabla donde se va a guardar el archivo (ej. $usuario->foto)
    */
    public function cargarArchivoBlobORM($archivo,$campoTabla){
        $fp = fopen($archivo["tmp_name"], "rb");
            $contenido = fread($fp, filesize($archivo["tmp_name"]));
            $contenido = base64_encode($contenido);
            fclose($fp);
            $arrayArchivo = array('nombre' => $archivo["name"], "tipo" => $archivo["type"], "tamanio" => $archivo["size"], "contenido" => $contenido);
            $campoTabla = serialize($arrayArchivo);
    }

    /*
    * toma el elemento blob de una tabla, lo desencripta y lo guarda de forma local.
    * $campoTabla: recibe un parametro de entidad eloquent (ej. usuario->foto)
    */
    public function descargarArchivoBlobORM($campoTabla){
        $imagen = unserialize($campoTabla);
        $fd = fopen("./" . $imagen['nombre'], "wb");
        fwrite($fd, base64_decode($imagen['contenido']), $imagen['tamanio']);
        fclose($fd);
    }

}
