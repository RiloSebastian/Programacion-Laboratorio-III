<?php
require './clases/middleware.php';
require './vendor/autoload.php';

$config['displayErrorDetails'] = true;
$config['addContentLenghtHeader'] = false;
$app = new \Slim\App([ "settings" => $config ]);

$app->get("/TraerPersonas",function($request, $response){
    
    $array= $request->getQueryParams();
    $argNombre= $array["nombre"];
    $response->getBody()->write(" GET esta bien, nombre: $argNombre");
    return $response;
});

$app->post("/AgregarPersona",function($request, $response){
    $arrayBody= $request->getParsedBody();
    $argEdad= $arrayBody["edad"];
    $response->getBody()->write(" POST esta bien edad: $argEdad");
    return $response;
});

$app->put("/ModificarPersona",function($request, $response){
    $array= $request->getQueryParams();
    $argEstado= $array["estado"];
    $response->getBody()->write(" PUT esta bien, estado: $argEstado");
    return $response;
});

$app->delete("/EliminarPersona",function( $request, $response){
    $array= $request->getQueryParams();
    $argEntrada= $array["entrada"];
    $response->getBody()->write(" DELETE esta bien, entrada: $argEntrada");
    return $response;
});

$app->run();
?>