<?php

class APP 
{
    //Trae todos los objetos del archivo y los parsea  su clase
    public function TraerTodos($request, $response)
    {

    }
    //igual que Traer Todos con un solo objeto
    public function TraerUno($request, $response)
    {

    }
    //agrega un objeto al archivo
    public function AgregarUno($request, $response)
    {

    }
    //modifica un objeto del archivo
    public function ModificarUno($request, $response)
    {

    }
    //elimina un objeto del Archivo
    public function EliminarUno($request, $response)
    {

    }

}


?>