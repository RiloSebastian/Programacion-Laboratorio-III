<?php
class Persona{
public $nombre;
public $edad;
public $id;
public $email;


public function __construct($nombre,$edad,$id,$email)
{
    $this->nombre = $nombre;
    $this->edad = $edad;
    $this->id = $id;
    $this->email = $email;
}
}


?>