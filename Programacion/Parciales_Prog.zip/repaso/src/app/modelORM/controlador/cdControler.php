<?php
namespace App\Models\ORM;

use App\Models\AutentificadorJWT;
use App\Models\ORM\ingreso;
use App\Models\ORM\user;

include_once __DIR__ . './../clases/user.php';
include_once __DIR__ . './../clases/ingreso.php';
include_once __DIR__ . './../clases/genericDao.php';
include_once __DIR__ . './../../modelAPI/AutentificadorJWT.php';

class cdControler
{
    public function traerTodos($request, $response, $args)
    {
        $newResponse = user::all();
        return $response->withJson($newResponse);
    }

    public function traerUno($request, $response, $args)
    {
        $id = $args['id'];
        $newResponse = user::find(id);
        return $response->withJson($newResponse);
    }

    //genera un token con algunos datos de la entidad especificados en un array
    public function logIn($request, $response)
    {
        $body = $request->getParsedBody();
        $coleccion = user::all();
        foreach ($coleccion as $elemento) {
            if ($elemento->legajo === (int) $body['legajo'] &&
                strtolower($elemento->email) === strtolower($body['email']) &&
                password_verify($body['clave'], $elemento->clave)) {
                $datos = array(
                    'legajo' => $elemento->legajo,
                    'email' => $elemento->email,
                    'fotoUno' => $elemento->fotoUno,
                    'fotodos' => $elemento->fotoDos,
                );
                $jwt = AutentificadorJWT::CrearToken($datos);
                $newResponse = $response->withJson($jwt);
                break;
            }
        }
        if (empty($newResponse)) {
            $newResponse = $response->getBody()->write('no existe un usuario con estos parametros');
        }
        return $newResponse;
    }

    public function cargarUser($request, $response)
    {
        $body = $request->getParsedBody();
        $archivos = $request->getUploadedFiles();
        $user = new user;
        $user->legajo = (int) $body['legajo'];
        $user->email = $body['email'];
        $user->clave = password_hash($body['clave'], PASSWORD_DEFAULT);
        $rutaImagen = \Dao::moverArchivos($archivos['fotoUno'], './imagenes/user/', $body['email'], 1);
        $user->fotoUno = $rutaImagen;
        $rutaImagen = \Dao::moverArchivos($archivos['fotoDos'], './imagenes/user/', $body['email'], 2);
        $user->fotoDos = $rutaImagen;
        $user->save();

        $mostrar = user::find((int) $body['legajo']);
        unset($mostrar->clave);
        $newResponse = $response->withJson($mostrar);
        return $newResponse;
    }

    public function ingreso($request, $response)
    {
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        $legajo = $datos['legajo'];
        $ingreso = new ingreso;
        $ingreso->legajo_user = $legajo;
        $ingreso->estado = 'INGRESO';
        $ingreso->save();

        $user = user::find($legajo);
        $user->estado = 1;
        $user->save();
        return $response->withJson($ingreso);
    }

    public function egreso($request, $response)
    {
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        $legajo = $datos['legajo'];
        $egreso = new ingreso;
        $egreso->legajo_user = $legajo;
        $egreso->estado = 'EGRESO';
        $egreso->save();

        $user = user::find($legajo);
        $user->estado = 0;
        $user->save();
        return $response->withJson($egreso);
    }

    public function mostrarIngresos($request, $response)
    {
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        $ultimos = array();
        if ($datos['legajo'] >= 1 && $datos['legajo'] <= 100) {
            $ids = ingreso::where('estado', 'INGRESO')->groupBy('legajo_user')->pluck('legajo_user');
            foreach ($ids as $id) {
                $ingresos = ingreso::where('legajo_user', $id)->where('estado', 'INGRESO')->orderBy('Created_at', 'desc')->first();
                array_push($ultimos, $ingresos);
                $ingresos = $ultimos;
            }
        } else {
            $legajo = $datos['legajo'];
            $ingresos = ingreso::where('legajo_user', $legajo)->where('estado', 'INGRESO')->get();
        }
        return $response->withJson($ingresos);
    }

    /*
     * guarda un archivo en el campo blob de una tabla en la base de datos
     * $archivo: un elemento obtenido de $_FILES para guardar (ej. $_FILES['imagen'])
     * $campoTabla: el campo tipo blob de la tabla donde se va a guardar el archivo (ej. $usuario->foto)
     */
    public function cargarArchivoBlobORM($archivo, $campoTabla)
    {
        $fp = fopen($archivo["tmp_name"], "rb");
        $contenido = fread($fp, filesize($archivo["tmp_name"]));
        $contenido = base64_encode($contenido);
        fclose($fp);
        $arrayArchivo = array('nombre' => $archivo["name"], "tipo" => $archivo["type"], "tamanio" => $archivo["size"], "contenido" => $contenido);
        $campoTabla = serialize($arrayArchivo);
    }

    /*
     * toma el elemento blob de una tabla, lo desencripta y lo guarda de forma local.
     * $campoTabla: recibe un parametro de entidad eloquent (ej. usuario->foto)
     */
    public function descargarArchivoBlobORM($campoTabla)
    {
        $imagen = unserialize($campoTabla);
        $fd = fopen("./" . $imagen['nombre'], "wb");
        fwrite($fd, base64_decode($imagen['contenido']), $imagen['tamanio']);
        fclose($fd);
    }

}
