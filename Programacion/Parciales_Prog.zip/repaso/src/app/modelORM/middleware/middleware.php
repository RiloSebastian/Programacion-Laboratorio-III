<?php

use App\Models\AutentificadorJWT;
use App\Models\ORM\log;
use App\Models\ORM\user;

include_once __DIR__ . './../clases/user.php';
include_once __DIR__ . './../clases/log.php';
include_once __DIR__ . './../../modelAPI/AutentificadorJWT.php';

class Middleware
{
    public function validarToken($request, $response, $next)
    {
        $token = $request->getHeader('token');
        if (!empty($token)) {
            $datos = AutentificadorJWT::obtenerData($token[0]);
            if (!empty($datos) && user::find($datos['legajo']) !== null) {
                $response = $next($request, $response);
            } else {
                $response->getBody()->write('no se encuentra el usuario');
            }
        } else {
            $response->getBody()->write('no se paso un token');
        }
        return $response;
    }

    public function esAdmin($request, $response, $next)
    {
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        if ($datos['tipo'] === 'admin') {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('no es admin');
        }
        return $response;
    }

    public function validarDatosCargaruser($request, $response, $next)
    {
        $body = $request->getParsedBody();
        $archivos = $request->getUploadedFiles();
        if (isset($body['legajo']) && isset($body['email']) &&
            isset($body['clave']) && isset($archivos['fotoUno']) && isset($archivos['fotoDos'])) {
            if ((int) $body['legajo'] >= 1 && (int) $body['legajo'] <= 1000) {
                if (user::where('legajo', (int) $body['legajo'])->exists() === false) {
                    $response = $next($request, $response);
                } else {
                    $response->getBody()->write('un usuario con este legajo ya existe');
                }
            } else {
                $response->getBody()->write('legajo fuera de rango aceptado');
            }
        } else {
            $response->getBody()->write('faltan parametros');
        }
        return $response;
    }

    public function logs($request, $response, $next)
    {
        $token = $request->getHeader('token');
        if (!empty($token)) {
            $usuario = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
            $nombreUsuario = $usuario['email'];
        } else {
            $nombreUsuario = 'no hay usuario logeado';
        }
        $log = new log;
        $log->metodo = $request->getMethod();
        $log->ruta = $request->getUri()->getPath();
        $log->ip = $request->getServerParam('REMOTE_ADDR');
        $log->usuario = $nombreUsuario;
        $log->save();
        $response = $next($request, $response);
        return $response;
    }

    public function validarIngreso($request, $response, $next)
    {
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        $ingresado = user::find($datos['legajo']);
        if ($ingresado->estado === 0) {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('el usuario ya esta ingresado');
        }
        return $response;
    }

    public function validarEgreso($request, $response, $next)
    {
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        $ingresado = user::find($datos['legajo']);
        if ($ingresado->estado === 1) {
            $response = $next($request, $response);
        } else {
             $response->getBody()->write('el usuario no esta ingresado. no se puede egresar');
        }
        return $response;
    }
}
