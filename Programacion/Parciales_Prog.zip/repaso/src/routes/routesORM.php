<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\cdControler;

include_once __DIR__ . '/../../src/app/modelORM/controlador/cdControler.php';
include_once __DIR__ . '/../../src/app/modelORM/middleware/middleware.php';

return function (App $app) {
    $container = $app->getContainer();

     $app->group('/Usuarios', function () {   
         
        $this->get('/mostrarTodos', cdControler::class . ':traerTodos');

        $this->get('/traerUno/{id}', cdControler::class . ':traerUno');        
        
        $this->post('/Users', cdControler::class . ':cargarUser')->add( Middleware::class . ':validarDatosCargaruser');      

        $this->post('/Login', cdControler::class . ':logIn');
        
        $this->put('/Ingreso', cdControler::class . ':ingreso')->add( Middleware::class . ':validarToken')->add( Middleware::class . ':validarIngreso');

        $this->put('/Egreso', cdControler::class . ':egreso')->add( Middleware::class . ':validarToken')->add( Middleware::class . ':validarEgreso');

        $this->get('/Ingreso', cdControler::class . ':mostrarIngresos');
        
    })->add(Middleware::class . ':logs');
};