<?php

use App\Models\AutentificadorJWT;
use App\Models\ORM\usuario;

include_once __DIR__ . './../clases/usuario.php';
include_once __DIR__ . './../../modelAPI/AutentificadorJWT.php';

class Middleware
{
    public function validarToken($request, $response, $next)
    {
        $token = $request->getHeader('token');
        if (!empty($token[0])) {
            $datos =AutentificadorJWT::obtenerData($token[0]);
            if (!empty($datos) && usuario::find($datos['id']) != null) {
                $response = $next($request, $response);
            } else {
                $response->getBody()->write('no se encuentra el usuario');
            }
        } else {
            $response->getBody()->write('no se paso un token');
        }
        return $response;
    }

    public function esAdmin($request, $response, $next)
    {
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        if ($datos['tipo'] === 'admin') {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('no es admin');
        }
        return $response;
    }
}
