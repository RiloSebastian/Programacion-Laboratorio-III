<?php

use App\Models\ORM\usuarioControler;
use Slim\App;

include_once __DIR__ . '/../../src/app/modelORM/clases/usuario.php';
include_once __DIR__ . '/../../src/app/modelORM/clases/alumno.php';
include_once __DIR__ . '/../../src/app/modelORM/clases/profesor.php';
include_once __DIR__ . '/../../src/app/modelORM/clases/admin.php';
include_once __DIR__ . '/../../src/app/modelORM/controladores/usuarioControler.php';
include_once __DIR__ . '/../../src/app/modelORM/middleware/middlewareUsuario.php';

return function (App $app) {
    $container = $app->getContainer();

    $app->group('/Usuarios', function () {

        $this->get('/TraerTodos', usuarioControler::class . ':traerTodos');

        $this->get('/TraerUno/{id}', usuarioControler::class . ':traerUno');

        /*$this->put('/ModificarUno/{id}', usuarioControler::class . ':ModificarUno');

        $this->delete('/EliminarUno/{id}', usuarioControler::class . ':BorrarUno');*/

        $this->post('/Usuario', usuarioControler::class . ':cargarUsuario');

        $this->post('/logIn', usuarioControler::class . ':logIn');

        $this->post('/materia', usuarioControler::class . ':cargarMateria')->add(Middleware::class . ':validarToken')->add(Middleware::class . ':esAdmin');

        $this->post('/usuario/{id}', usuarioControler::class . ':modificarUsuario')->add(Middleware::class . ':validarToken');;

        $this->post('/inscripcion/{id}', usuarioControler::class . ':inscribirAlumno')->add(Middleware::class . ':validarToken');;

        $this->get('/materias', usuarioControler::class . ':mostrarMaterias')->add(Middleware::class . ':validarToken');;

        $this->get('/materias/{id}', usuarioControler::class . ':mostrarAlumnos')->add(Middleware::class . ':validarToken');;
    });

    $app->group('/usuarioORM2', function () {

        $this->get('/', usuarioControler::class . ':traerTodos');

    });

};
