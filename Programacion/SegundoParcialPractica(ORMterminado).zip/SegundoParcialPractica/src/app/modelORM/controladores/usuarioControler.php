<?php
namespace App\Models\ORM;

use App\Models\AutentificadorJWT;
use App\Models\IApiControler;
use App\Models\ORM\admin;
use App\Models\ORM\alumno;
use App\Models\ORM\materia;
use App\Models\ORM\profesor;
use App\Models\ORM\relacion;
use App\Models\ORM\usuario;

include_once __DIR__ . './../clases/usuario.php';
include_once __DIR__ . './../clases/alumno.php';
include_once __DIR__ . './../clases/profesor.php';
include_once __DIR__ . './../clases/admin.php';
include_once __DIR__ . './../clases/relacion_usuario-materia.php';
include_once __DIR__ . './../clases/materia.php';
include_once __DIR__ . './../../modelAPI/IApiControler.php';
include_once __DIR__ . './../../modelAPI/AutentificadorJWT.php';

class usuarioControler implements IApiControler
{
    public function Beinvenida($request, $response, $args)
    {
        $response->getBody()->write("GET => Bienvenido!!! ,a UTN FRA SlimFramework");
        return $response;
    }

    public function TraerTodos($request, $response, $args)
    {
        $todosLosusuarios = usuario::all();
        $newResponse = $response->withJson($todosLosusuarios, 200);
        return $newResponse;
    }

    public function TraerUno($request, $response, $args)
    {
        $id = $args['id'];
        $usuarioElegido = usuario::find($id);
        $newResponse = $response->withJson($usuarioElegido, 200);
        return $newResponse;
    }

    public function CargarUno($request, $response, $args)
    {
        $usuario = new usuario;
        $parametros = $request->getParsedBody();
        $usuario->email = $parametros['email'];
        $usuario->clave = $parametros['clave'];
        $usuario->tipo = $parametros['tipo'];
        $usuario->save();
        $usuarioElegido = usuario::find("$usuario->id");
        $newResponse = $response->withJson($usuarioElegido, 200);
        return $newResponse;
    }

    public function BorrarUno($request, $response, $args)
    {
        $id = $args['id'];
        $usuarioElegido = usuario::find($id);
        $usuarioElegido->delete();
        $todosLosusuarios = usuario::all();
        $newResponse = $response->withJson($todosLosusuarios, 200);
        return $newResponse;
    }

    public function ModificarUno($request, $response, $args)
    {
        $id = $args['id'];
        $usuarioElegido = usuario::find($id);
        $parametros = $request->getParsedBody();
        $usuarioElegido->email = $parametros['email'];
        $usuarioElegido->clave = $parametros['clave'];
        $usuarioElegido->tipo = $parametros['tipo'];
        $usuarioElegido->save();
        $newResponse = $response->withJson($usuarioElegido, 200);
        return $newResponse;
    }

    public function cargarUsuario($request, $response, $args)
    {
        $parametros = $request->getParsedBody();
        $usuario = new usuario;
        $usuario->nombre = $parametros['nombre'];
        $usuario->email = $parametros['email'];
        $usuario->clave = $parametros['clave'];
        $usuario->tipo = $parametros['tipo'];
        $usuario->save();
        if ($parametros['tipo'] === 'alumno') {
            $tipo = new alumno;
        } else if ($parametros['tipo'] === 'profesor') {
            $tipo = new profesor;
        } else {
            $tipo = new admin;
        }
        $tipo->id = $usuario->id;
        $tipo->save();
        $usuarioElegido = usuario::find("$usuario->id");
        $newResponse = $response->withJson($usuarioElegido, 200);
        return $newResponse;
    }

    public function logIn($request, $response)
    {
        $parametros = $request->getParsedBody();
        $coleccion = usuario::where('clave', $parametros['clave'])->get();
        foreach ($coleccion as $elemento) {
            if ($elemento->nombre === $parametros['nombre']) {
                $datos = array('id' => "$elemento->id", 'nombre' => "$elemento->nombre", 'email' => "$elemento->email", 'tipo' => "$elemento->tipo");
                $jwt = AutentificadorJWT::CrearToken($datos);
                $newResponse = $response->withJson($jwt);
                break;
            }
        }
        if (empty($newResponse)) {
            $newResponse = $response->getBody()->write('no existe un usuario con estos parametros');
        }
        return $newResponse;
    }

    public function cargarMateria($request, $response)
    {
        $parametros = $request->getParsedBody();
        $materia = new materia;
        $materia->nombre = $parametros['nombre'];
        $materia->cuatrimestre = $parametros['cuatrimestre'];
        $materia->cupo = (int) $parametros['cupo'];
        $materia->save();
        $newResponse = $response->withJson($materia);
        return $newResponse;
    }

    public function modificarUsuario($request, $response, $args)
    {
        $flag = -1;
        $id = $args['id'];
        $parametros = $request->getParsedBody();
        $archivo = $_FILES['imagen'];
        $usuario = usuario::find($id);
        $datos = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        if (($datos['tipo'] === 'alumno' && $datos['id'] == $id) || $datos['tipo'] === 'admin') {
            $usuario->email = $parametros['email'];
            $alumno = alumno::find($id);
            $fp = fopen($archivo["tmp_name"], "rb");
            $contenido = fread($fp, filesize($archivo["tmp_name"]));
            $contenido = base64_encode($contenido);
            fclose($fp);
            $arrayArchivo = array('nombre' => $archivo["name"], "tipo" => $archivo["type"], "tamanio" => $archivo["size"], "contenido" => $contenido);
            $alumno->foto = serialize($arrayArchivo);
            $alumno->save();
            $newResponse = $response->withJson($usuario);
        } else {
            $flag = 1;
        }
        if (($datos['tipo'] === 'profesor' && $datos['id'] == $id) || $datos['tipo'] === 'admin') {
            $flag = -1;
            $usuario->email = $parametros['email'];
            relacion::where('id_usuario', $id)->delete();
            $arrayMaterias = explode(',', $parametros['materias']);
            foreach ($arrayMaterias as $materia) {
                if (!(relacion::where('id_usuario', $id)->where('id_materia', $materia)->exists()) && materia::find($materia) != null) {
                    $relacion = new relacion;
                    $relacion->id_usuario = $id;
                    $relacion->tipo = $usuario->tipo;
                    $relacion->id_materia = $materia;
                    $relacion->save();
                    $newResponse = $response->withJson($usuario);
                }
            }
        } else {
            $flag = 1;
        }
        if ($flag == 1) {
            $newResponse = $response->getBody()->write('el usuario logeado no puede modificar al usuario elegido');
        }
        $usuario->save();
        return $newResponse;
    }

    public function inscribirAlumno($request, $response, $args)
    {
        $id = $args['id'];
        $parametros = $request->getParsedBody();
        $data = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        $materia = materia::find($id);
        if ($materia->cupo > 0) {
            if (!(relacion::where('id_usuario', $id)->where('id_materia', $materia)->exists())) {
                $relacion = new relacion;
                $relacion->id_usuario = $data['id'];
                $relacion->tipo = $data['tipo'];
                $relacion->id_materia = $id;
                $relacion->save();
                $materia->cupo--;
                $materia->save();
                $newResponse = $response->withJson($relacion);
            } else {
                $newResponse = $response->getBody()->write('el alumno ya esta inscripto a la materia');
            }
        } else {
            $newResponse = $response->getBody()->write('no hay cupos para esta materia');
        }
        return $newResponse;
    }

    public function mostrarMaterias($request, $response, $args)
    {
        $data = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        if ($data['tipo'] === 'alumno' || $data['tipo'] === 'profesor') {
            $arrayMaterias = relacion::where('id_usuario', $data['id'])->pluck('id_materia')->toArray();
            $listaMaterias = array();
            foreach ($arrayMaterias as $idMateria) {
                $materia = materia::find($idMateria);
                array_push($listaMaterias, $materia);
            }
            $newResponse = $response->withJson($listaMaterias);
        } else if ($data['tipo'] === 'admin') {
            $arrayMaterias = materia::all();
            $newResponse = $response->withJson($arrayMaterias);
        }
        return $newResponse;
    }

    public function mostrarAlumnos($request, $response, $args)
    {
        $id = $args['id'];
        $data = AutentificadorJWT::obtenerData($request->getHeader('token')[0]);
        if ($data['tipo'] === 'admin' ||
            ($data['tipo'] === 'profesor' && relacion::where('id_usuario', $data['id'])->where('id_materia', $id)->exists())) {
            $arrayUsuarios = relacion::where('id_materia', $id)->where('tipo', 'alumno')->pluck('id_usuario')->toArray();
            $listaUsuarios = array();
            foreach ($arrayUsuarios as $idUsuarios) {
                $usuario = usuario::find($idUsuarios);
                array_push($listaUsuarios, $usuario);
            }
            $newResponse = $response->withJson($listaUsuarios);
        }
        else
        {
            $newResponse = $response->getBody()->write('el usuario no es del tipo correcto');
        }
        
        return $newResponse;
    }

    public function descargarImagenesAlumno($request, $response, $args)
    {
        $id = $args['id'];
        $alumno = alumno::find($id);
        $imagen = unserialize($alumno->foto);
        $fd = fopen("./" . $imagen['nombre'], "wb");
        fwrite($fd, base64_decode($imagen['contenido']), $imagen['tamanio']);
        fclose($fd);
    }
}
