<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\cdControler;

include_once __DIR__ . '/../../src/app/modelORM/controlador/cdControler.php';
include_once __DIR__ . '/../../src/app/modelORM/middleware/middleware.php';

return function (App $app) {
    $container = $app->getContainer();

     $app->group('/Usuario', function () {   
         
        $this->get('/mostrarTodos', cdControler::class . ':traerTodos');

        $this->get('/traerUno/{id}', cdControler::class . ':traerUno');        
        
        $this->get('/cargarUno', cdControler::class . ':cargarUno');        
        
        $this->get('/modificarUno/{id}', cdControler::class . ':modificarUno');        
        
        $this->get('/borrarUno{id}', cdControler::class . ':borrarUno');        

    });
};