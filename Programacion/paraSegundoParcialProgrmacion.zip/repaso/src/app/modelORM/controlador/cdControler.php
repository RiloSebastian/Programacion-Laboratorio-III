<?php
namespace App\Models\ORM;

use App\Models\ORM\usuario;
use App\Models\ORM\alumno;
use App\Models\ORM\profesor;
use App\Models\ORM\relacion;
use App\Models\ORM\admin;
use App\Models\ORM\materia;
use App\Models\IApiControler;

include_once __DIR__ . './../clases/usuario.php';
include_once __DIR__ . './../clases/alumno.php';
include_once __DIR__ . './../clases/profesor.php';
include_once __DIR__ . './../clases/relacion.php';
include_once __DIR__ . './../clases/admin.php';
include_once __DIR__ . './../clases/materia.php';
include_once __DIR__ . './../../modelAPI/IApiControler.php';
include_once __DIR__ . './../../modelAPI/AutentificadorJWT.php';

class cdControler
{
    public function traerTodos($request, $response, $args)
    {
        $newResponse = usuario::all();
        return $response->withJson($newResponse);
    }

    public function traerUno($request, $response, $args)
    {
        $id = $args['id'];
        $newResponse = usuario::find(id);
        return $response->withJson($newResponse);
    }

    public function cargarUno($request, $response)
    {
        $parametros = $request->getParsedBody();
        $usuario = new usuario;
        $usuario->nombre = $parametros['nombre'];
        $usuario->email = $parametros['email'];
        $usuario->clave = $parametros['clave'];
        $usuario->tipo = $parametros['tipo'];
        $usuario->save();
        return $response->withJson($usuario);
    }

    public function ModificarUno($request, $response, $args)
    {
        $id = $args['id'];
        $parametros = $request->getParsedBody();
        $usuario = usuario::find($id);
        $usuario->nombre = $parametros['nombre'];
        $usuario->email = $parametros['email'];
        $usuario->clave = $parametros['clave'];
        $usuario->tipo = $parametros['tipo'];
        $usuario->save();
        return $response->withJson($usuario);
    }

    public function borrarUno($request, $response, $args)
    {
        $id = $args['id'];
        $usuario = usuario::find($id);
        $usuario->delete();
        $newResponse = usuario::all();
        return $response->withJson($newResponse);
    }

    //genera un token con algunos datos de la entidad especificados en un array
    public function logIn($request, $response)
    {
        $parametros = $request->getParsedBody();
        $coleccion = usuario::where('clave', $parametros['clave'])->get();
        foreach ($coleccion as $elemento) {
            //si hay que hacer la consulta directamente uppercase... Model::whereRaw("UPPER('.$column.') LIKE '%'". strtoupper($value)."'%'"); 
            if (strtolower($elemento->nombre) === strtolower($parametros['nombre'])) {
                $datos = array('id' => "$elemento->id", 'nombre' => "$elemento->nombre", 'email' => "$elemento->email", 'tipo' => "$elemento->tipo");
                $jwt = AutentificadorJWT::CrearToken($datos);
                $newResponse = $response->withJson($jwt);
                break;
            }
        }
        if (empty($newResponse)) {
            $newResponse = $response->getBody()->write('no existe un usuario con estos parametros');
        }
        return $newResponse;
    }


    /*
    * guarda un archivo en el campo blob de una tabla en la base de datos
    * $archivo: un elemento obtenido de $_FILES para guardar (ej. $_FILES['imagen'])
    * $campoTabla: el campo tipo blob de la tabla donde se va a guardar el archivo (ej. $usuario->foto)
    */
    public function cargarArchivoBlobORM($archivo,$campoTabla){
        $fp = fopen($archivo["tmp_name"], "rb");
            $contenido = fread($fp, filesize($archivo["tmp_name"]));
            $contenido = base64_encode($contenido);
            fclose($fp);
            $arrayArchivo = array('nombre' => $archivo["name"], "tipo" => $archivo["type"], "tamanio" => $archivo["size"], "contenido" => $contenido);
            $campoTabla = serialize($arrayArchivo);
    }

    /*
    * toma el elemento blob de una tabla, lo desencripta y lo guarda de forma local.
    * $campoTabla: recibe un parametro de entidad eloquent (ej. usuario->foto)
    */
    public function descargarArchivoBlobORM($campoTabla){
        $imagen = unserialize($campoTabla);
        $fd = fopen("./" . $imagen['nombre'], "wb");
        fwrite($fd, base64_decode($imagen['contenido']), $imagen['tamanio']);
        fclose($fd);
    }

}
