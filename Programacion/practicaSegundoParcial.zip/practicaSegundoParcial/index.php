<?php
require_once './vendor/autoload.php';
require_once './controladores/Api.php';
require_once './clases/persona.php';
require_once './clases/middleware.php';
require_once './clases/genericDao.php';
require_once './clases/tokens.php';

$config["displayErrorDetails"] = true;
$config["addContentLengthHeader"] = false;
$app = new \Slim\App(["settings" => $config]);

$app->get('/JWT/crearToken', \ApiPersona::class . ':CrearToken');

$app->group('/miPagina', function () {

    $this->get("/TraerTodos", \ApiPersona::class . ':TraerTodos')->add(\Middleware::class . ':esAdmin');

    $this->get("/TraerUno/{id}", \ApiPersona::class . ':TraerUno')->add(\Middleware::class . ':esAdmin')
        ->add(\Middleware::class . ':tieneId');

    $this->post("/AgregarUno", \ApiPersona::class . ':AgregarUno')->add(\Middleware::class . ':esAdmin')
        ->add(\Middleware::class . ':tieneParametros');

    $this->delete("/EliminarUno/{id}", \ApiPersona::class . ':EliminarUno')->add(\Middleware::class . ':esAdmin')
        ->add(\Middleware::class . ':tieneId');

    $this->post("/ModificarUno/{id}", \ApiPersona::class . ':ModificarUno')->add(\Middleware::class . ':esAdmin')
        ->add(\Middleware::class . ':tieneId')
        ->add(\Middleware::class . ':tieneParametros');
});

$app->run();
