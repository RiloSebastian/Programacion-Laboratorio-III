<?php

class Persona{
    public $id;
    public $nombre;
    public $edad;
    public $email;
    public $archivo;

    public function __construct($id,$nombre,$edad,$email,$archivo){
        $this->id = $id;
        $this->nombre = $nombre;
        $this->edad = $edad;
        $this->email = $email;
        $this->archivo = $archivo;
    }
}