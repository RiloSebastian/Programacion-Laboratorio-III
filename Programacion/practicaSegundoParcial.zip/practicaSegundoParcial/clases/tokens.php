<?php
//hay que instalar firebase con: 'composer require firebase/php-jwt'
use \Firebase\JWT\JWT;

class Token
{
    public static $cifrado = 'HS256';
    public static $claveSecreta = 'miClaveNoTanSecreta123';

    //si se le va a agregar fechas de expiracion, darles una suma elevada porque expiran rapido.
    //recordar actualizar los headers segun la contraseña y los datos que vayamos modificando.
    public static function generarToken()
    {
        $ahora = time();
        $payload = array(
            'iat' => $ahora,
            'exp' => $ahora + (3000000000),
            'admin' => true,
        );
        $token = JWT::encode($payload, self::$claveSecreta);
        return $token;
    }

    public static function verificarToken($token)
    {
        if (empty($token) || $token === "") {
            throw new Exception('el token esta vacio');
        }
        try {
            $decodificado = JWT::decode($token, self::$claveSecreta, [self::$cifrado]);
        } catch (Exception $e) {
            throw new Exception('el token no es valido. ' . $e->getMessage());
        }
        return (array) $decodificado;
    }
}
