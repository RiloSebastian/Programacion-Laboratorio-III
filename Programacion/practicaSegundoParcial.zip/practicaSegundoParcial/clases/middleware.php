<?php

class Middleware
{

    public $archivoPersona;
    public function __construct()
    {
        $this->archivoPersona = new DAO('./MOCK_DATA.json');
    }

    public function esAdmin($request, $response, $next)
    {
        $token = $request->getHeader('token');
        $tokenDecodificado = Token::verificarToken($token[0]);
        if ($tokenDecodificado['admin']) {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('no es administrador. no puede realizar esta operacion');
        }
        return $response;
    }

    public function tieneId($request, $response, $next)
    {
        $paramsRuta = $request->getAttribute('routeInfo')[2];
        if (isset($paramsRuta['id']) && in_array((int) $paramsRuta['id'], $this->archivoPersona->ObtenerArrayDeValor('id'))) {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write(PHP_EOL . 'no existe una persona con ese id');
        }
        return $response;
    }

    public function tieneParametros($request, $response, $next)
    {
        $method = $request->getMethod();
        if ($method === 'PUT') {
            $arrayParams = $request->getQueryParams();
        } else if ($method === 'POST') {
            $arrayParams = $request->getParsedBody();
        }
        if (isset($arrayParams['nombre'], $arrayParams['edad'], $arrayParams['email']) &&
            strlen($arrayParams['nombre']) > 1 && strlen($arrayParams['edad']) > 0 && strlen($arrayParams['email']) > 5) {
            $response = $next($request, $response);
        } else {
            $response->getBody()->write('faltan parametros por completar');
        }
        return $response;
    }
}
