<?php

class DAO
{

    public $archivo;
    public function __construct($archivo)
    {
        $this->archivo = $archivo;
    }

    public function guardar($objeto): bool
    {
        try {
            $objetos = array();
            if (file_exists($this->archivo)) {
                $objetos = json_decode($this->listar());
            }
            $archivo = fopen($this->archivo, "w");
            array_push($objetos, $objeto);
            fwrite($archivo, json_encode($objetos));
            return true;
        } catch (Exception $e) {
            throw new Exception("El objeto no se guardo", 0, $e);
        } finally {
            fclose($archivo);
        }
    }

    public function listar()
    {
        try {
            if (file_exists($this->archivo)) {
                $archivo = fopen($this->archivo, "r");
                return fread($archivo, filesize($this->archivo));
            } else {
                return null;
            }
        } catch (Exception $e) {
            throw new Exception("El archivo No se pudo listar", 0, $e);
        } finally {
            if (file_exists($this->archivo)) {
                fclose($archivo);
            }
        }
    }

    public function borrar($nombreClave, $valor): bool
    {
        try {
            $retorno = false;
            $objetos = json_decode($this->listar());
            $archivo = fopen($this->archivo, "w");
            foreach ($objetos as $clave => $objeto) {
                if ($objeto->$nombreClave == $valor) {
                    unset($objetos[$clave]);
                    $objetos = array_values($objetos);
                    $retorno = true;
                    break;
                }
            }
            fwrite($archivo, json_encode($objetos));
            return $retorno;
        } catch (Exception $e) {
            throw new Exception("El objeto no se borro", 0, $e);
        } finally {
            fclose($archivo);
        }
    }

    public function modificar($nombreClave, $valor, $claveModificada, $valorModificado): bool
    {
        try {
            $retorno = false;
            $objetos = json_decode($this->listar());
            if ($objetos != null) {
                $archivo = fopen($this->archivo, "w");
                foreach ($objetos as $objeto) {
                    if ($objeto->$nombreClave == $valor) {
                        $objeto->$claveModificada = $valorModificado;
                        $retorno = true;
                        break;
                    }
                }
                fwrite($archivo, json_encode($objetos));
            }
            return $retorno;
        } catch (Exception $e) {
            throw new Exception("El objeto no se pudo modificar", 0, $e);
        } finally {
            if ($objetos != null) {
                fclose($archivo);
            }
        }
    }

    public function obtenerPorId($idKey, $idValue)
    {
        $objects = json_decode($this->listar());
        if ($objects != null) {
            foreach ($objects as $object) {
                if ($object->$idKey == $idValue) {
                    return $object;
                }
            }
        }
        return null;
    }

    public function getByAttribute($attrKey, $attrValue)
    {
        try {
            $objects = json_decode($this->listar());
            $retorno = array();
            foreach ($objects as $object) {
                if ($object->$attrKey == $attrValue) {
                    array_push($retorno, $object);
                }
            }
            if (count($retorno) > 0) {
                return json_encode($retorno);
            } else {
                return null;
            }
        } catch (Exception $e) {
            throw new Exception("El archivo No se listo segun el parametro '$attrKey' ", 0, $e);
        }
    }
    public function getByAttributeCaseInsensitive($attrKey, $attrValue)
    {
        try {
            $objects = json_decode($this->listar());
            $retorno = array();
            foreach ($objects as $object) {
                if (strtolower($object->$attrKey) == strtolower($attrValue)) {
                    array_push($retorno, $object);
                }
            }
            if (count($retorno) > 0) {
                return json_encode($retorno);
            } else {
                return null;
            }
        } catch (Exception $e) {
            throw new Exception("El archivo No se listo segun el parametro '$attrKey' ", 0, $e);
        }
    }

    public function ObtenerArrayDeValor($attrKey)
    {
        $objects = json_decode($this->listar());
        if ($objects != null) {
            $retorno = array();
            foreach ($objects as $object) {
                if (isset($object->$attrKey)) {
                    array_push($retorno, $object->$attrKey);
                }
            }
            return $retorno;
        }
        return null;
    }

    public function obtenerValor($idKey, $idValue, $attrKey)
    {
        $object = $this->obtenerPorId($idKey, $idValue);
        if (isset($object->$attrKey)) {
            return $object->$attrKey;
        }
        return null;
    }

    public function GenerarNuevoId()
    {
        $max = 1;
        $objects = json_decode($this->listar());
        if ($objects != null) {
            foreach ($objects as $object) {
                if ($object->id > $max) {
                    $max = $object->id;
                }
            }
            return $max + 1;
        }
        return 1;
    }

    public function cantidadDeObjetosEnArchivo()
    {
        $contador = 0;
        $objects = json_decode($this->listar());
        if ($objects != null) {
            foreach ($objects as $object) {
                $contador++;
            }
            return $contador;
        }
        return 0;
    }

    public function moverArchivos($archivo, $destino, $identificadorPrimario, $identificadorSecundario)
    {
        $nombre = $archivo->getClientFileName();
        $extension = explode('.', $nombre);
        $extension = array_reverse($extension);
        $nuevaRuta = $destino . $identificadorPrimario . '_' . $identificadorSecundario . '.' . $extension[0];
        $archivo->moveTo($nuevaRuta);
        return $nuevaRuta;
    }

    public function reemplazarArchivos($destino, $archivoOriginal, $archivoNuevo, $dest, $idPrim, $idSec)
    {
        $extension = explode('.', $archivoOriginal);
        $extension = array_reverse($extension);
        $fecha = date('Y-m-d-H-i');
        $rutaNuevaArchivoOriginal = $destino . $idPrim . '_' . $idSec . '_' . $fecha . '.' . $extension[0];
        rename($archivoOriginal, $rutaNuevaArchivoOriginal);
        $rutaArchivoNuevo = $this->moverArchivos($archivoNuevo, $dest, $idPrim, $idSec);
        return $rutaArchivoNuevo;
    }
}
